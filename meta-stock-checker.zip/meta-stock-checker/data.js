// Built-in data. EVERY rate here is a PLACEHOLDER to be confirmed by you / your customs agent.
// status: 'confirmed' = listed by Meta/Ray-Ban as supported, 'reported' = press reports (verify),
//         'other' = Meta sells other hardware there; AI glasses may not be sold.
var MSC_DATA = {
  countries: [
    // cc, name, region, currency, local VAT % (placeholder), status
    ['US', 'United States', 'Americas', 'USD', 0, 'confirmed'],
    ['CA', 'Canada', 'Americas', 'CAD', 5, 'confirmed'],
    ['BR', 'Brazil', 'Americas', 'BRL', 0, 'confirmed'],
    ['MX', 'Mexico', 'Americas', 'MXN', 16, 'reported'],
    ['GB', 'United Kingdom', 'Europe', 'GBP', 20, 'confirmed'],
    ['IE', 'Ireland', 'Europe', 'EUR', 23, 'confirmed'],
    ['FR', 'France', 'Europe', 'EUR', 20, 'confirmed'],
    ['DE', 'Germany', 'Europe', 'EUR', 19, 'confirmed'],
    ['IT', 'Italy', 'Europe', 'EUR', 22, 'confirmed'],
    ['ES', 'Spain', 'Europe', 'EUR', 21, 'confirmed'],
    ['NL', 'Netherlands', 'Europe', 'EUR', 21, 'confirmed'],
    ['BE', 'Belgium', 'Europe', 'EUR', 21, 'confirmed'],
    ['AT', 'Austria', 'Europe', 'EUR', 20, 'confirmed'],
    ['FI', 'Finland', 'Europe', 'EUR', 25.5, 'confirmed'],
    ['DK', 'Denmark', 'Europe', 'DKK', 25, 'confirmed'],
    ['NO', 'Norway', 'Europe', 'NOK', 25, 'confirmed'],
    ['SE', 'Sweden', 'Europe', 'SEK', 25, 'confirmed'],
    ['AU', 'Australia', 'Asia-Pacific', 'AUD', 10, 'confirmed'],
    ['IN', 'India', 'Asia-Pacific', 'INR', 18, 'reported'],
    ['AE', 'United Arab Emirates', 'Middle East', 'AED', 5, 'reported'],
    ['IS', 'Iceland', 'Europe', 'ISK', 24, 'other'],
    ['PL', 'Poland', 'Europe', 'PLN', 23, 'other'],
    ['CH', 'Switzerland', 'Europe', 'CHF', 8.1, 'other'],
    ['JP', 'Japan', 'Asia-Pacific', 'JPY', 10, 'other'],
    ['KR', 'South Korea', 'Asia-Pacific', 'KRW', 10, 'other'],
    ['TW', 'Taiwan', 'Asia-Pacific', 'TWD', 5, 'other'],
    ['NZ', 'New Zealand', 'Asia-Pacific', 'NZD', 15, 'other']
  ],
  // slug = path after /ai-glasses/ . All of these were seen as live links on meta.com (Oct 2026).
  // Meta changes its range often: press "Discover products" to refresh from the live store.
  products: [
    ['ray-ban-meta-gen-3-wayfarer', 'Ray-Ban Meta Gen 3 Wayfarer', true],
    ['ray-ban-meta-gen-3-aviator-havana-brown-transitions', 'Ray-Ban Meta Gen 3 Aviator (Havana, Brown Transitions)', true],
    ['ray-ban-meta-gen-3-zena-shiny-black-graphite-green-transitions', 'Ray-Ban Meta Gen 3 Zena (Shiny Black)', true],
    ['ray-ban-meta-gen-2', 'Ray-Ban Meta Gen 2', true],
    ['wayfarer', 'Ray-Ban Meta Wayfarer Gen 1', true],
    ['ray-ban-meta-audio', 'Ray-Ban Meta Audio', true],
    ['ray-ban-meta-audio-clubmaster', 'Ray-Ban Meta Audio Clubmaster', true],
    ['oakley-meta', 'Oakley Meta', true],
    ['meta-ray-ban-display', 'Meta Ray-Ban Display', true]
  ],
  // Meta stores whose shown price does NOT include sales tax (tax is added at checkout).
  priceExclTax: ['US', 'CA'],
  // All Amazon marketplaces. cc, name, domain, region, currency, VAT/GST % (placeholder), price shown includes tax? (false = tax added at checkout)
  amazon: [
    ['US', 'United States', 'amazon.com', 'Americas', 'USD', 0, false],
    ['CA', 'Canada', 'amazon.ca', 'Americas', 'CAD', 5, false],
    ['MX', 'Mexico', 'amazon.com.mx', 'Americas', 'MXN', 16, true],
    ['BR', 'Brazil', 'amazon.com.br', 'Americas', 'BRL', 17, true],
    ['GB', 'United Kingdom', 'amazon.co.uk', 'Europe', 'GBP', 20, true],
    ['DE', 'Germany', 'amazon.de', 'Europe', 'EUR', 19, true],
    ['FR', 'France', 'amazon.fr', 'Europe', 'EUR', 20, true],
    ['IT', 'Italy', 'amazon.it', 'Europe', 'EUR', 22, true],
    ['ES', 'Spain', 'amazon.es', 'Europe', 'EUR', 21, true],
    ['NL', 'Netherlands', 'amazon.nl', 'Europe', 'EUR', 21, true],
    ['BE', 'Belgium', 'amazon.com.be', 'Europe', 'EUR', 21, true],
    ['IE', 'Ireland', 'amazon.ie', 'Europe', 'EUR', 23, true],
    ['SE', 'Sweden', 'amazon.se', 'Europe', 'SEK', 25, true],
    ['PL', 'Poland', 'amazon.pl', 'Europe', 'PLN', 23, true],
    ['TR', 'Turkey', 'amazon.com.tr', 'Middle East', 'TRY', 20, true],
    ['AE', 'United Arab Emirates', 'amazon.ae', 'Middle East', 'AED', 5, true],
    ['SA', 'Saudi Arabia', 'amazon.sa', 'Middle East', 'SAR', 15, true],
    ['EG', 'Egypt', 'amazon.eg', 'Africa', 'EGP', 14, true],
    ['ZA', 'South Africa', 'amazon.co.za', 'Africa', 'ZAR', 15, true],
    ['IN', 'India', 'amazon.in', 'Asia-Pacific', 'INR', 18, true],
    ['JP', 'Japan', 'amazon.co.jp', 'Asia-Pacific', 'JPY', 10, true],
    ['SG', 'Singapore', 'amazon.sg', 'Asia-Pacific', 'SGD', 9, true],
    ['AU', 'Australia', 'amazon.com.au', 'Asia-Pacific', 'AUD', 10, true]
  ],
  // USD per 1 unit of currency (placeholders)
  fx: {
    USD: 1, GBP: 1.3, EUR: 1.1, AUD: 0.65, CAD: 0.72, DKK: 0.147, NOK: 0.093, SEK: 0.095,
    BRL: 0.18, INR: 0.012, MXN: 0.052, AED: 0.272, JPY: 0.0066, KRW: 0.00072, CHF: 1.15,
    PLN: 0.25, NZD: 0.59, TWD: 0.031, ISK: 0.0072, TRY: 0.023, SAR: 0.267, EGP: 0.02, ZAR: 0.056, SGD: 0.75
  },
  // Destination = where YOUR customer is. duty % / VAT % are placeholders.
  dest: [
    ['AE', 'United Arab Emirates', 0, 5],
    ['IN', 'India', 20, 18],
    ['SA', 'Saudi Arabia', 5, 15],
    ['QA', 'Qatar', 5, 0],
    ['KW', 'Kuwait', 5, 0],
    ['OM', 'Oman', 5, 5],
    ['BH', 'Bahrain', 5, 10],
    ['GB', 'United Kingdom', 0, 20],
    ['US', 'United States', 0, 0],
    ['HK', 'Hong Kong', 0, 0],
    ['SG', 'Singapore', 0, 9],
    ['AU', 'Australia', 0, 10]
  ],
  helpUrl: 'https://www.meta.com/en-gb/help/ai-glasses/4961066940605960/'
};
if (typeof module !== 'undefined' && module.exports) module.exports = MSC_DATA;
