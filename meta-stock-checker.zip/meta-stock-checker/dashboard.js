'use strict';
/* Meta Stock Checker dashboard. The check engine runs here (an extension page stays alive while open). */
var D = MSC_DATA, M = MSC;
var $ = function (s) { return document.querySelector(s); };
var sleep = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };
function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }

var STATUS_LABEL = { IN_STOCK: 'In stock', OUT_OF_STOCK: 'Out of stock', NOT_SOLD: 'Not sold here', NOTIFY: 'Notify me', PREORDER: 'Pre-order',
  COMING_SOON: 'Coming soon', REDIRECTED: 'Redirected', BLOCKED: 'Blocked – check tab', UNKNOWN: 'Unclear', ERROR: 'Error' };

/* ---------- state ---------- */
function defaults() {
  return {
    selCountries: D.countries.filter(function (c) { return c[5] !== 'other'; }).map(function (c) { return c[0]; }),
    selProducts: D.products.map(function (p) { return p[0]; }),
    customProducts: [], customCountries: [], listedByMeta: {}, sites: [], selSites: [], closed: {}, targets: {}, nameOverride: {}, srcOpts: {}, fxLive: null, hiddenProducts: {}, openP: {}, closedB: {}, brands: {},
    logistics: {}, results: {},
    settings: { concurrency: 5, cacheHours: 3, timeoutSec: 25, logisticsDefault: 3, destCode: 'AE', destDuty: 0, destVat: 5, margin: 15,
      includesVat: true, fx: JSON.parse(JSON.stringify(D.fx)),
      b2bOn: true, wpUrl: 'https://aiglasses.ae', wpKey: '', autoPush: true, autoHours: 3, autoMig: 1, lastAuto: 0, wpLast: '', listen: true, fxManual: {} }
  };
}
var S = defaults();
var saveT = null;
function save() { clearTimeout(saveT); saveT = setTimeout(function () { chrome.storage.local.set({ msc: S }); }, 300); syncSave(); }
/* Copy of lists/settings (not results, not the WordPress key) in Chrome sync, so a re-install brings everything back. */
function configOnly() { var c = JSON.parse(JSON.stringify(S)); delete c.results; delete c.fxLive; c.settings.wpKey = ''; c.settings.wpLast = ''; return c; }
var syncT = null, lastSync = '';
function syncSave() {
  clearTimeout(syncT);
  syncT = setTimeout(async function () {
    try {
      var str = JSON.stringify(configOnly()); if (str === lastSync) return;
      var parts = []; for (var i = 0; i < str.length; i += 6000) parts.push(str.slice(i, i + 6000));
      if (parts.length > 12) { syncMsg('Chrome sync copy is too big (' + Math.round(str.length / 1024) + ' KB). Use Save everything and keep the file.'); return; }
      var o = { cfgN: parts.length }; parts.forEach(function (p, i) { o['cfg' + i] = p; });
      var old = await chrome.storage.sync.get('cfgN');
      await chrome.storage.sync.set(o);
      var drop = []; for (var j = parts.length; j < (old.cfgN || 0); j++) drop.push('cfg' + j);
      if (drop.length) await chrome.storage.sync.remove(drop);
      lastSync = str; syncMsg('Copy in Chrome sync saved ' + new Date().toLocaleTimeString() + ' (' + Math.round(str.length / 1024) + ' KB).');
    } catch (e) {}
  }, 2500);
}
async function syncRead() {
  try {
    var n = (await chrome.storage.sync.get('cfgN')).cfgN || 0; if (!n) return null;
    var keys = []; for (var i = 0; i < n; i++) keys.push('cfg' + i);
    var got = await chrome.storage.sync.get(keys), str = ''; keys.forEach(function (k) { str += got[k] || ''; });
    return JSON.parse(str);
  } catch (e) { return null; }
}
function applyConfig(c, keepResults) {
  var d = defaults(), keepKey = S.settings && S.settings.wpKey, keepRes = S.results;
  S = Object.assign(d, c);
  S.settings = Object.assign(d.settings, c.settings || {});
  S.settings.fx = Object.assign({}, d.settings.fx, (c.settings || {}).fx || {});
  if (keepKey) S.settings.wpKey = keepKey;
  if (keepResults !== false && !c.results) S.results = keepRes || {};
  ensureTargets();
}
async function load() {
  var got = await chrome.storage.local.get('msc');
  if (got.msc) {
    var d = defaults();
    S = Object.assign(d, got.msc);
    S.settings = Object.assign(d.settings, got.msc.settings || {});
    S.settings.fx = Object.assign({}, d.settings.fx, (got.msc.settings || {}).fx || {});
    if (!(got.msc.settings || {}).autoMig) { S.settings.autoMig = 1; if (!S.settings.autoHours) S.settings.autoHours = 3; S.settings.autoPush = true; S.settings.listen = true; }
    ensureTargets();
  } else {
    var c = await syncRead();
    ensureTargets();
    if (c) { applyConfig(c); setTimeout(function () { banner('Restored your lists and settings from Chrome sync. Press Auto-fill key to reconnect WordPress.'); save(); }, 300); }
  }
}
function ensureTargets() {
  if (!S.targets) S.targets = {};
  D.dest.forEach(function (d) {
    if (!S.targets[d[0]]) S.targets[d[0]] = { name: d[1], duty: d[2], vat: d[3], extra: 0, fixed: 0, margin: S.settings.margin != null ? Number(S.settings.margin) : 15, log: S.settings.logisticsDefault != null ? Number(S.settings.logisticsDefault) : 3, ship: {} };
  });
  Object.keys(S.targets).forEach(function (k) { if (S.targets[k].fixed == null) S.targets[k].fixed = 0; });
  if (!S.targets.GL) S.targets.GL = { name: 'Global (every other website)', duty: 0, vat: 0, extra: 0, fixed: 0, margin: S.settings.margin != null ? Number(S.settings.margin) : 15, log: 3, ship: {}, cur: 'USD', type: 'B2C', sell: true, push: true };
  if (!S.sellInit) { S.sellInit = 1; if (S.targets.AE) { S.targets.AE.sell = true; S.targets.AE.push = true; if (S.targets.AE.host == null) S.targets.AE.host = 'aiglasses.ae'; if (!S.targets.AE.cur) S.targets.AE.cur = 'AED'; } }
  if (!S.defaultsV) { // one-time: move old placeholder defaults (shipping 25, margin 20, UAE duty 5) to the new defaults
    S.defaultsV = 2;
    Object.keys(S.targets).forEach(function (k) { var t = S.targets[k]; if (t.log === 25) t.log = 3; if (t.margin === 20) t.margin = 15; if (k === 'AE' && t.duty === 5) t.duty = 0; });
    if (S.settings.logisticsDefault === 25) S.settings.logisticsDefault = 3; if (S.settings.margin === 20) S.settings.margin = 15;
  }
  ensureAmazonSites(); if (!S.srcOpts) S.srcOpts = {}; if (!S.settings.fxManual) S.settings.fxManual = {};
  if (!S.targets[S.settings.destCode]) S.settings.destCode = 'AE';
  if (S.logistics && Object.keys(S.logistics).length) { // older versions kept one shipping list; move it to the current target
    var t = S.targets[S.settings.destCode];
    Object.keys(S.logistics).forEach(function (k) { if (t.ship[k] == null) t.ship[k] = S.logistics[k]; });
    S.logistics = {};
  }
}
function curTarget() { ensureTargets(); return S.targets[S.settings.destCode]; }
function srcKey(r) { return r.site ? 'site:' + r.site : r.cc; }
function siteById(id) { return S.sites.find(function (x) { return x.id === id; }); }
function ensureAmazonSites() {
  if (!S.sites) S.sites = [];
  D.amazon.forEach(function (a) {
    var id = 'amz-' + a[0].toLowerCase();
    if (S.sites.some(function (x) { return x.id === id; })) return;
    S.sites.push({ id: id, kind: 'amazon', name: a[2], region: a[3], cc: a[0], cur: a[4], vat: a[5], vatMode: a[6] ? 'included' : 'extra', refund: null,
      pattern: 'https://www.' + a[2] + '/dp/{id}', searchUrl: 'https://www.' + a[2] + '/s?k={q}', urls: [] });
  });
}
function uid() { return Math.random().toString(36).slice(2, 9); }
function itemKey(site, it) { return 'site:' + site.id + '|' + (it.uid || it.url); }
// Tax set-up of one source (Meta country or website): vat %, mode ('included' | 'extra'), refund (null = use the default checkbox)
function srcCfg(key) {
  var o = (S.srcOpts && S.srcOpts[key]) || {}, vat = 0, mode = 'included', refund = null;
  if (key.indexOf('site:') === 0) { var st = siteById(key.slice(5)); if (st) { vat = Number(st.vat) || 0; mode = st.vatMode || 'included'; refund = st.refund == null ? null : st.refund; } }
  else { var c = countryInfo(key); vat = c ? Number(c.vat) || 0 : 0; mode = D.priceExclTax.indexOf(key) !== -1 ? 'extra' : 'included'; }
  return { vat: o.vat != null ? o.vat : vat, mode: o.mode || mode, refund: o.refund != null ? o.refund : refund };
}
function effRefund(cfg) { return cfg.refund == null ? !!S.settings.includesVat : !!cfg.refund; }
function allCountries() {
  var extra = S.customCountries.map(function (c) { return [c.cc, c.name, c.region || 'Other', c.cur, c.vat, 'custom']; });
  return D.countries.concat(extra);
}
function allProducts() {
  var ov = S.nameOverride || {};
  var extra = S.customProducts.map(function (p) { return [p.slug, ov[p.slug] || p.name, !!p.discovered, true]; });
  var hid = S.hiddenProducts || {};
  return D.products.filter(function (p) { return !hid[p[0]]; }).map(function (p) { return [p[0], ov[p[0]] || p[1], p[2], false]; }).concat(extra);
}
function countryInfo(cc) {
  var c = allCountries().find(function (x) { return x[0] === cc; });
  return c ? { cc: c[0], name: c[1], region: c[2], cur: c[3], vat: c[4], status: c[5] } : null;
}

/* ---------- render: countries / products / settings ---------- */
var REGIONS = ['Americas', 'Europe', 'Asia-Pacific', 'Middle East', 'Africa', 'Other'];
function regionIdx(r) { var i = REGIONS.indexOf(r); return i < 0 ? 99 : i; }
function renderCountries() {
  var q = ($('#cSearch').value || '').toLowerCase();
  var list = allCountries().filter(function (c) { return !q || c[1].toLowerCase().indexOf(q) !== -1 || c[0].toLowerCase() === q || ('meta.com/' + c[0].toLowerCase()).indexOf(q) !== -1; });
  list.sort(function (x, y) { return regionIdx(x[2]) - regionIdx(y[2]) || x[0].localeCompare(y[0]); });
  $('#countryList').innerHTML = list.map(function (c) {
    var st = S.listedByMeta[c[0]] ? 'confirmed' : c[5], on = S.selCountries.indexOf(c[0]) !== -1;
    return '<label class="chip' + (on ? ' on' : '') + (st === 'other' ? ' dim' : '') + '" title="' + esc(c[1] + ' · ' + c[2] + ' · ' + (st === 'other' ? 'unlikely' : st)) + '"><input type="checkbox" data-cc="' + c[0] + '"' + (on ? ' checked' : '') + '>meta.com/' + c[0].toLowerCase() + '</label>';
  }).join('') || '<span class="hint">No match</span>';
  $('#cCount').textContent = S.selCountries.length + ' ticked';
}
function siteLabel(s) { return s.name + (s.cc ? ' (' + s.cc + ')' : ''); }
function siteChip(x, amazon) {
  var on = S.selSites.indexOf(x.id) !== -1, n = x.urls.length;
  return '<span class="chip' + (on ? ' on' : '') + '" title="' + esc((x.region || 'Other') + ' · ' + (x.cc || '–') + ' · ' + (x.cur || '–') + ' · ' + n + ' listing(s)') + '"><label><input type="checkbox" data-site="' + esc(x.id) + '"' + (on ? ' checked' : '') + '>' + esc(x.name) + (amazon ? (n ? ' <i>' + n + '</i>' : '') : (x.cc ? ' <i>' + esc(x.cc) + '</i>' : '')) + '</label>' +
    '<button class="mini" data-sedit="' + esc(x.id) + '" title="Edit">✎</button>' + (amazon ? '' : '<button class="mini" data-sdel="' + esc(x.id) + '" title="Remove">✕</button>') + '</span>';
}
function renderSites() {
  var by = function (x, y) { return regionIdx(x.region) - regionIdx(y.region) || x.name.localeCompare(y.name); };
  var web = S.sites.filter(function (x) { return x.kind !== 'amazon'; }).sort(by), amz = S.sites.filter(function (x) { return x.kind === 'amazon'; }).sort(by);
  $('#siteList').innerHTML = web.map(function (x) { return siteChip(x, false); }).join('') || '<span class="hint">No websites yet. Press + Add website.</span>';
  $('#amazonList').innerHTML = amz.map(function (x) { return siteChip(x, true); }).join('');
  $('#wsCount').textContent = web.filter(function (x) { return S.selSites.indexOf(x.id) !== -1; }).length + ' ticked';
  $('#amzCount').textContent = amz.filter(function (x) { return S.selSites.indexOf(x.id) !== -1; }).length + ' ticked';
  renderShip(); if ($('#flSource')) renderFindSources();
}
/* ---------- costing slab + shipping table ---------- */
/* ---------- selling countries: one row each ---------- */
function sellCodes() { ensureTargets(); return Object.keys(S.targets).filter(function (k) { return S.targets[k].sell; }).sort(function (a, b) { return a === 'GL' ? 1 : b === 'GL' ? -1 : S.targets[a].name.localeCompare(S.targets[b].name); }); }
function renderSell() {
  var tb = $('#sellBody'); if (!tb) return;
  tb.innerHTML = sellCodes().map(function (k) {
    var t = S.targets[k], c = esc(k);
    var num = function (f, w) { return '<td><input class="shipin" style="width:' + (w || 58) + 'px" type="number" step="0.5" min="0" data-tr="' + c + '" data-f="' + f + '" value="' + esc(t[f] == null ? '' : t[f]) + '"></td>'; };
    var chk = function (f) { return '<td><input type="checkbox" data-trc="' + c + '" data-f="' + f + '"' + (t[f] ? ' checked' : '') + '></td>'; };
    return '<tr' + (k === S.settings.destCode ? ' class="cur"' : '') + '><td><b>' + esc(t.name) + '</b> <small>' + c + '</small></td>' +
      '<td><input class="shipin" style="width:150px" data-tr="' + c + '" data-f="host" placeholder="' + (k === 'GL' ? 'all other websites' : 'example.com') + '" value="' + esc(t.host || '') + '"' + (k === 'GL' ? ' disabled' : '') + '></td>' +
      '<td><select data-tr="' + c + '" data-f="type"><option value="B2C"' + (t.type === 'B2B' ? '' : ' selected') + '>B2C</option><option value="B2B"' + (t.type === 'B2B' ? ' selected' : '') + '>B2B</option></select></td>' +
      '<td><input class="shipin" style="width:50px" maxlength="3" data-tr="' + c + '" data-f="cur" value="' + esc(t.cur || '') + '"></td>' +
      num('duty') + num('vat') + num('extra') + num('log') + num('margin') + num('fixed') + num('marginB2b') + num('fixedB2b') + chk('sameB2c') + chk('round') + chk('push') +
      '<td><button data-tview="' + c + '" title="Show this country in the table below">view</button></td><td>' + (k === 'GL' ? '' : '<button class="x" data-tdel="' + c + '" title="Remove this country">✕</button>') + '</td></tr>';
  }).join('');
}
function setTarget(code, f, v) {
  var t = S.targets[code]; if (!t) return;
  if (f === 'host') { t.host = String(v).toLowerCase().split(/[\s,]+/).map(function (x) { return x.replace(/^https?:\/\//, '').replace(/^www\./, '').replace(/\/.*$/, ''); }).filter(Boolean).join(', '); return; }
  if (f === 'type') { t.type = v === 'B2B' ? 'B2B' : 'B2C'; return; }
  if (f === 'cur') { t.cur = String(v).trim().toUpperCase(); return; }
  if (f === 'marginB2b' || f === 'fixedB2b') { if (String(v).trim() === '') delete t[f]; else t[f] = Number(v) || 0; return; }
  t[f] = Number(v) || 0;
}
function renderSlab() {
  ensureTargets();
  var t = curTarget();
  $('#tTarget').innerHTML = Object.keys(S.targets).sort(function (a, b) { return S.targets[a].name.localeCompare(S.targets[b].name); }).map(function (k) {
    return '<option value="' + esc(k) + '"' + (k === S.settings.destCode ? ' selected' : '') + '>' + esc(S.targets[k].name + ' (' + k + ')') + '</option>'; }).join('');
  $('#tDuty').value = t.duty; $('#tVat').value = t.vat; $('#tExtra').value = t.extra; $('#tLog').value = t.log; $('#tMargin').value = t.margin; $('#tFixed').value = t.fixed; $('#tMarginB2b').value = t.marginB2b == null ? '' : t.marginB2b; $('#tFixedB2b').value = t.fixedB2b == null ? '' : t.fixedB2b; $('#tSame').checked = !!t.sameB2c; $('#tHost').value = t.host || ''; $('#tType').value = t.type || 'B2C'; $('#tCur').value = t.cur || ''; $('#tRound').checked = !!t.round; $('#tPush').checked = !!t.push; $('#sB2bOn').checked = S.settings.b2bOn !== false;
  $('#sIncl').checked = !!S.settings.includesVat;
  renderShip(); renderBrands(); renderSell();
}
function renderShip() {
  if ($('#shipBox').hidden) return;
  var t = curTarget(), q = ($('#shipFilter').value || '').toLowerCase(), rows = [];
  allCountries().slice().sort(function (x, y) { return regionIdx(x[2]) - regionIdx(y[2]) || x[0].localeCompare(y[0]); }).forEach(function (c) { rows.push({ key: c[0], label: 'meta.com/' + c[0].toLowerCase(), name: c[1] + ' · ' + c[2] }); });
  S.sites.filter(function (x) { return x.kind === 'amazon'; }).forEach(function (x) { rows.push({ key: 'site:' + x.id, label: x.name, name: x.cc + ' · ' + (x.region || '') }); });
  S.sites.filter(function (x) { return x.kind !== 'amazon'; }).forEach(function (x) { rows.push({ key: 'site:' + x.id, label: x.name, name: (x.cc ? x.cc + ' · ' : '') + (x.region || 'Other') }); });
  var defRef = S.settings.includesVat ? 'Yes' : 'No';
  $('#shipBody').innerHTML = rows.filter(function (r) { return !q || (r.label + ' ' + r.name).toLowerCase().indexOf(q) !== -1; }).map(function (r) {
    var o = S.srcOpts[r.key] || {}, cfg = srcCfg(r.key), rf = o.refund == null ? '' : (o.refund ? 'yes' : 'no');
    var sel = function (attr, val, opts) { return '<select ' + attr + '="' + esc(r.key) + '">' + opts.map(function (x) { return '<option value="' + x[0] + '"' + (x[0] === val ? ' selected' : '') + '>' + x[1] + '</option>'; }).join('') + '</select>'; };
    return '<tr><td>' + esc(r.label) + '</td><td>' + esc(r.name) + '</td>' +
      '<td><input class="shipin" data-ship="' + esc(r.key) + '" type="number" min="0" step="0.5" placeholder="' + esc(t.log) + '" value="' + esc(t.ship[r.key] == null ? '' : t.ship[r.key]) + '"></td>' +
      '<td><input data-svat="' + esc(r.key) + '" type="number" min="0" step="0.5" placeholder="' + esc(cfg.vat) + '" value="' + esc(o.vat == null ? '' : o.vat) + '"></td>' +
      '<td>' + sel('data-smode', o.mode || '', [['', 'Default (' + (cfg.mode === 'extra' ? 'tax at checkout' : 'includes VAT') + ')'], ['included', 'Includes VAT'], ['extra', 'Tax at checkout']]) + '</td>' +
      '<td>' + sel('data-srefund', rf, [['', 'Default (' + (cfg.refund == null ? defRef : (cfg.refund ? 'Yes' : 'No')) + ')'], ['yes', 'Yes'], ['no', 'No']]) + '</td></tr>';
  }).join('');
}
function setSrcOpt(key, field, v) {
  var o = S.srcOpts[key] = S.srcOpts[key] || {};
  if (v === '' || v == null) delete o[field]; else o[field] = field === 'vat' ? Number(v) : field === 'refund' ? v === 'yes' : v;
  if (!Object.keys(o).length) delete S.srcOpts[key];
}
function setShip(key, v) { var t = curTarget(); v = String(v).trim().replace(/[^0-9.\-]/g, ''); if (v === '') delete t.ship[key]; else t.ship[key] = Number(v); }
function optsOf(slug) { var c = S.customProducts.find(function (x) { return x.slug === slug; }); return c && c.opts ? c.opts : ''; }
function groupOf(p) { var c = S.customProducts.find(function (x) { return x.slug === p[0]; }); return (c && c.model) || String(p[1]).split(' – ')[0]; }
function renderProducts() {
  var pq = ($('#pSearch').value || '').toLowerCase(), brands = [], bidx = {};
  allProducts().forEach(function (p) {
    if (pq && (p[0] + ' ' + p[1]).toLowerCase().indexOf(pq) === -1) return;
    var bn = brandOf(p[1]); if (bidx[bn] == null) { bidx[bn] = brands.length; brands.push({ name: bn, groups: [], idx: {}, items: [] }); }
    var B = brands[bidx[bn]], g = groupOf(p); if (B.idx[g] == null) { B.idx[g] = B.groups.length; B.groups.push({ name: g, items: [] }); }
    B.groups[B.idx[g]].items.push(p); B.items.push(p);
  });
  S.openP = S.openP || {}; S.closedB = S.closedB || {};
  var row = function (p, ind) {
    return '<div class="item' + (ind ? ' sub' : '') + '"><label><input type="checkbox" data-slug="' + esc(p[0]) + '"' + (S.selProducts.indexOf(p[0]) !== -1 ? ' checked' : '') + '> ' + esc(ind ? String(p[1]).replace(/^.*? – /, '') : p[1]) +
      ' <span class="tag ' + (p[2] ? 'confirmed' : '') + '">' + (p[2] ? 'verified' : 'unverified') + '</span>' + (optsOf(p[0]) ? '<span class="sub2" title="' + esc(optsOf(p[0])) + '"> ⓘ sizes</span>' : '') + '</label>' +
      (p[3] ? '<button class="x" data-del="' + esc(p[0]) + '" title="Remove">✕</button>' : '') + '</div>';
  };
  var html = '';
  brands.forEach(function (B) {
    var bon = B.items.filter(function (p) { return S.selProducts.indexOf(p[0]) !== -1; }).length, bopen = !!pq || !S.closedB[B.name], bc = brandCfg(B.name);
    html += '<div class="grp bgrp"><button class="fold" data-bfold="' + esc(B.name) + '" title="Expand / collapse brand">' + (bopen ? '▾' : '▸') + '</button>' +
      '<label><input type="checkbox" data-bgroup="' + esc(B.name) + '"' + (bon === B.items.length ? ' checked' : '') + (bon && bon < B.items.length ? ' data-partial="1"' : '') + '> <b>' + esc(B.name) + '</b></label>' +
      (bc.b2b === false ? '<span class="tag">B2B off</span>' : '') + (bc.b2c === false ? '<span class="tag">B2C off</span>' : '') + '<span class="count">' + bon + '/' + B.items.length + '</span></div>';
    if (!bopen) return;
    B.groups.forEach(function (g) {
      if (g.items.length === 1) { html += row(g.items[0], false); return; }
      var on = g.items.filter(function (p) { return S.selProducts.indexOf(p[0]) !== -1; }).length, open = !!pq || !!S.openP[g.name];
      html += '<div class="grp pgrp"><button class="fold" data-pfold="' + esc(g.name) + '" title="Expand / collapse">' + (open ? '▾' : '▸') + '</button>' +
        '<label><input type="checkbox" data-pgroup="' + esc(g.name) + '"' + (on === g.items.length ? ' checked' : '') + (on && on < g.items.length ? ' data-partial="1"' : '') + '> <b>' + esc(g.name) + '</b></label><span class="count">' + on + '/' + g.items.length + '</span></div>';
      if (open) g.items.forEach(function (p) { html += row(p, true); });
    });
  });
  $('#productList').innerHTML = html;
  $('#productList').querySelectorAll('[data-partial]').forEach(function (el) { el.indeterminate = true; });
  $('#pCount').textContent = S.selProducts.length + ' ticked';
  if ($('#pRestore')) $('#pRestore').hidden = !Object.keys(S.hiddenProducts || {}).some(function (k) { return S.hiddenProducts[k]; });
  renderBrands();
}
function renderSettings() {
  var s = S.settings;
  $('#sConc').value = s.concurrency; $('#sCache').value = s.cacheHours; $('#sTimeout').value = s.timeoutSec;
  $('#wUrl').value = s.wpUrl || ''; $('#wKey').value = s.wpKey || ''; $('#wAuto').checked = !!s.autoPush; $('#wListen').checked = s.listen !== false; $('#wHours').value = s.autoHours || 0; $('#wStatus').textContent = s.wpLast || '';
  renderFx();
}

/* ---------- results table ---------- */
/* ---------- brands ---------- */
function brandOf(name) {
  var n = String(name || '').toLowerCase().replace(/^\s+/, '');
  if (/^oakley/.test(n)) return 'Oakley Meta';
  if (/^ray-?ban meta/.test(n)) return 'Ray-Ban Meta';
  if (/^meta ray-?ban/.test(n)) return 'Meta Ray-Ban Display';
  if (/^meta\b/.test(n)) return 'Meta';
  var w = String(name || '').trim().split(/[\s–-]+/)[0]; return w || 'Other';
}
function brandCfg(name) { return (S.brands && S.brands[brandOf(name)]) || {}; }
function brandNum(v) { return v === '' || v == null || !isFinite(Number(v)) ? null : Number(v); }
function costSettings(tg) {
  var t = tg || curTarget(), s = S.settings;
  return { fx: s.fx, includesVat: s.includesVat, logisticsDefault: t.log, logistics: t.ship, destDuty: t.duty, destVat: t.vat, margin: t.margin, extra: t.extra, fixed: t.fixed,
    marginB2b: t.marginB2b, fixedB2b: t.fixedB2b, sameB2c: !!t.sameB2c };
}
// Brand's own numbers (blank = target-country numbers). A per-source shipping figure in the shipping table still wins.
function brandCs(cs, name) {
  var b = brandCfg(name), o = Object.assign({}, cs), v;
  if ((v = brandNum(b.mB2c)) != null) o.margin = v;
  if ((v = brandNum(b.fB2c)) != null) o.fixed = v;
  if ((v = brandNum(b.mB2b)) != null) o.marginB2b = v;
  if ((v = brandNum(b.fB2b)) != null) o.fixedB2b = v;
  if (b.same) o.sameB2c = true;
  if ((v = brandNum(b.extra)) != null) o.extra = v;
  if ((v = brandNum(b.duty)) != null) o.destDuty = v;
  if ((v = brandNum(b.log)) != null) o.logisticsDefault = v;
  return o;
}
// The prices the websites may use: B2B off (brand or master) / B2C off (brand) = no price.
function pubPrices(r) {
  var c = r.calc, b = brandCfg(r.product);
  if (!c) return { b2c: null, b2b: null };
  return { b2c: b.b2c === false ? null : c.sell, b2b: (b.b2b === false || S.settings.b2bOn === false) ? null : c.sellB2b };
}
function rowCalc(r, cs) {
  if (!r.price) return null;
  var k = srcKey(r), cfg = srcCfg(k);
  return M.computeLanded({ price: r.price, cur: r.cur, cc: k, srcVat: cfg.vat, vatMode: cfg.mode, refund: effRefund(cfg) }, brandCs(cs, r.product));
}
function brandList() {
  var m = {};
  allProducts().forEach(function (p) { var b = brandOf(p[1]); m[b] = (m[b] || 0) + 1; });
  Object.keys(S.brands || {}).forEach(function (b) { if (!m[b]) m[b] = 0; });
  return Object.keys(m).sort().map(function (b) { return { name: b, n: m[b] }; });
}
function renderBrands() {
  var tb = $('#brandBody'); if (!tb) return;
  var t = curTarget(), ph = function (v) { return v == null ? '' : v; };
  tb.innerHTML = brandList().map(function (b) {
    var c = (S.brands && S.brands[b.name]) || {}, n = esc(b.name);
    var num = function (f, place) { return '<td><input class="shipin" type="number" step="0.5" min="0" data-bf="' + f + '" data-brand="' + n + '" placeholder="' + esc(ph(place)) + '" value="' + esc(c[f] == null ? '' : c[f]) + '"></td>'; };
    var chk = function (f) { return '<td><input type="checkbox" data-bc="' + f + '" data-brand="' + n + '"' + (c[f] === false ? '' : ' checked') + '></td>'; };
    return '<tr><td><b>' + n + '</b></td><td>' + b.n + '</td>' + chk('b2b') + chk('b2c') + num('mB2b', t.marginB2b == null ? t.margin : t.marginB2b) + num('fB2b', t.fixedB2b == null ? t.fixed : t.fixedB2b) + num('mB2c', t.margin) + num('fB2c', t.fixed) +
      '<td><input type="checkbox" data-bs="same" data-brand="' + n + '"' + (c.same ? ' checked' : '') + '></td>' + num('extra', t.extra) + num('duty', t.duty) + num('log', t.log) + '</tr>';
  }).join('');
}
function setBrand(name, field, v) {
  S.brands = S.brands || {};
  var c = S.brands[name] = S.brands[name] || {};
  if (v === '' || v == null || v === true && (field === 'b2b' || field === 'b2c')) delete c[field]; else c[field] = v;
  if (v === false || v === true) { if (field === 'same' && !v) delete c.same; }
  if (!Object.keys(c).length) delete S.brands[name];
}
// A price in the target country's own currency for the website (sell price is calculated in USD).
function targetCur(code) { var c = countryInfo(code || S.settings.destCode); return c && c.cur && S.settings.fx[c.cur] ? c.cur : 'USD'; }
function tgtCur(code, t) { var c = String((t && t.cur) || '').toUpperCase(); return c && (c === 'USD' || S.settings.fx[c]) ? c : targetCur(code); }
// Final prices for one product row, for the current target (sell_*) and for every country that has "send to WordPress" ticked (prices).
function sellFields(r) {
  var one = function (code, t) {
    var c = rowCalc(r, costSettings(t)), pp = pubPrices({ product: r.product, calc: c }), cur = tgtCur(code, t), f = cur === 'USD' ? 1 : S.settings.fx[cur];
    var cv = function (v) { if (v == null) return null; var x = v / f; return t.round ? Math.round(x) : Math.round(x * 100) / 100; };
    return { cur: cur, b2c: cv(pp.b2c), b2b: cv(pp.b2b) };
  };
  var d = one(S.settings.destCode, curTarget()), out = { sell_b2c: d.b2c, sell_b2b: d.b2b, sell_cur: d.cur }, prices = {}, any = false;
  Object.keys(S.targets).forEach(function (k) { var t = S.targets[k]; if (t.sell && t.push) { prices[k] = one(k, t); any = true; } });
  if (any) out.prices = prices;
  return out;
}
function siteRules() {
  var o = [];
  Object.keys(S.targets).forEach(function (k) { var t = S.targets[k]; if (k === 'GL' || !t.sell || !t.push || !t.host) return; String(t.host).split(/[\s,]+/).filter(Boolean).forEach(function (h) { o.push({ host: h, cc: k, type: t.type === 'B2B' ? 'B2B' : 'B2C' }); }); });
  return o;
}
function globalRule() { var g = S.targets.GL; return g && g.sell && g.push ? { type: g.type === 'B2B' ? 'B2B' : 'B2C' } : null; }
// Final price of one row for any selling country, in that country's currency.
function finalFor(r, code) {
  var t = S.targets[code], c = rowCalc(r, costSettings(t)), pp = pubPrices({ product: r.product, calc: c }), cur = tgtCur(code, t), f = cur === 'USD' ? 1 : S.settings.fx[cur];
  var cv = function (v) { if (v == null) return null; var x = v / f; return t.round ? Math.round(x) : Math.round(x * 100) / 100; };
  return { cur: cur, b2c: cv(pp.b2c), b2b: cv(pp.b2b) };
}
function money(n) { return n == null ? '–' : n.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }); }
function ago(ts) {
  var m = Math.round((Date.now() - ts) / 60000);
  return m < 1 ? 'just now' : m < 60 ? m + ' min ago' : m < 1440 ? Math.round(m / 60) + ' h ago' : Math.round(m / 1440) + ' d ago';
}
var colSort = { key: '', dir: 1 };
function rowCountry(r) { if (!r.site) return r.country; var c = countryInfo(r.cc); return c ? c.name : (r.cc || r.country); }
function rowWeb(r) { return r.site ? (r.kind === 'amazon' ? 'Amazon · ' + r.source : r.source) : 'Meta.com'; }
function sortVal(r, k) {
  var c = r.calc || {};
  switch (k) {
    case 'product': return String(r.product).toLowerCase();
    case 'country': return (rowCountry(r) + ' ' + rowWeb(r)).toLowerCase();
    case 'status': return ({ IN_STOCK: 0, PREORDER: 1, NOTIFY: 2, COMING_SOON: 3, OUT_OF_STOCK: 4, NOT_SOLD: 5, REDIRECTED: 6 })[r.status] != null ? ({ IN_STOCK: 0, PREORDER: 1, NOTIFY: 2, COMING_SOON: 3, OUT_OF_STOCK: 4, NOT_SOLD: 5, REDIRECTED: 6 })[r.status] : 9;
    case 'price': return c.priceUsd == null ? null : c.priceUsd;
    case 'delivery': return r.delivery ? r.delivery.toLowerCase() : null;
    case 'net': return c.netUsd == null ? null : c.netUsd;
    case 'log': return c.logistics == null ? null : c.logistics;
    case 'duty': return c.duty == null ? null : c.duty;
    case 'vat': return c.vat == null ? null : c.vat;
    case 'extra': return c.extra == null ? null : c.extra;
    case 'landed': return c.landed == null ? null : c.landed;
    case 'sell': return c.sell == null ? null : c.sell;
    case 'profit': return c.profit == null ? null : c.profit;
    case 'sellb2b': return c.sellB2b == null ? null : c.sellB2b;
    case 'profitb2b': return c.profitB2b == null ? null : c.profitB2b;
    case 'checked': return r.checkedAt || 0;
  }
  return null;
}
function visibleRows() {
  var cs = costSettings();
  var rows = Object.keys(S.results).map(function (k) {
    var r = S.results[k];
    return Object.assign({}, r, { calc: rowCalc(r, cs) });
  });
  var f = $('#fStatus').value, t = ($('#fText').value || '').toLowerCase(), fs = $('#fSource').value, fp = $('#fProduct').value;
  rows = rows.filter(function (r) {
    if (f === 'in' && r.status !== 'IN_STOCK') return false;
    if (f === 'notin' && ['OUT_OF_STOCK', 'NOT_SOLD', 'REDIRECTED'].indexOf(r.status) === -1) return false;
    if (f === 'issue' && ['BLOCKED', 'ERROR', 'UNKNOWN'].indexOf(r.status) === -1) return false;
    if (fs && (r.source || 'Meta.com') !== fs) return false;
    if (fp && String(r.product).toLowerCase() !== fp) return false;
    if (t && (r.product + ' ' + r.country + ' ' + r.status + ' ' + r.cc + ' ' + (r.source || '')).toLowerCase().indexOf(t) === -1) return false;
    return true;
  });
  if ($('#fBest').checked) { // several listings of one product on one source: keep the best (available first, then cheapest)
    var grp = {};
    rows.forEach(function (r) {
      var k = (r.source || 'Meta.com') + '|' + (r.site ? '' : r.cc) + '|' + String(r.product).toLowerCase();
      var g = grp[k] = grp[k] || { best: null, n: 0 }; g.n++;
      var rank = function (x) { return (x.status === 'IN_STOCK' ? 0 : 1e9) + (x.calc ? x.calc.sell : 1e8); };
      if (!g.best || rank(r) < rank(g.best)) g.best = r;
    });
    rows = Object.keys(grp).map(function (k) { var b = grp[k].best; b.listings = grp[k].n; return b; });
  }
  if ($('#fLowest') && $('#fLowest').checked) { // cheapest in-stock source for each product name
    var low = {};
    rows.forEach(function (r) { if (r.status !== 'IN_STOCK' || !r.calc) return; var k = String(r.product).toLowerCase(); if (!low[k] || r.calc.sell < low[k].calc.sell) low[k] = r; });
    rows = Object.keys(low).map(function (k) { return low[k]; });
  }
  if (colSort.key) {
    rows.sort(function (a, b) {
      var x = sortVal(a, colSort.key), y = sortVal(b, colSort.key);
      if (x == null && y == null) return 0; if (x == null) return 1; if (y == null) return -1; // empty values always last
      return (x < y ? -1 : x > y ? 1 : 0) * colSort.dir;
    });
    return rows;
  }
  var sort = $('#fSort').value, big = 1e12, avail = function (r) { return r.status === 'IN_STOCK' ? 0 : r.status === 'PREORDER' || r.status === 'NOTIFY' || r.status === 'COMING_SOON' ? 1 : 2; };
  rows.sort(function (a, b) {
    if (sort === 'country') return a.country.localeCompare(b.country) || a.product.localeCompare(b.product);
    if (sort === 'status') return avail(a) - avail(b) || a.product.localeCompare(b.product) || (a.calc ? a.calc.sell : big) - (b.calc ? b.calc.sell : big);
    if (sort === 'price_asc') return (a.calc ? a.calc.sell : big) - (b.calc ? b.calc.sell : big);
    if (sort === 'price_desc') return (b.calc ? b.calc.sell : -1) - (a.calc ? a.calc.sell : -1);
    if (sort === 'landed') return (a.calc ? a.calc.landed : big) - (b.calc ? b.calc.landed : big);
    return a.product.localeCompare(b.product) || a.country.localeCompare(b.country);
  });
  return rows;
}
function fillFilters() {
  var srcs = {}, prods = {};
  Object.keys(S.results).forEach(function (k) { var r = S.results[k]; srcs[r.source || 'Meta.com'] = 1; prods[String(r.product).toLowerCase()] = r.product; });
  var fs = $('#fSource'), fp = $('#fProduct'), cs = fs.value, cp = fp.value;
  fs.innerHTML = '<option value="">All sources</option>' + Object.keys(srcs).sort().map(function (x) { return '<option' + (x === cs ? ' selected' : '') + '>' + esc(x) + '</option>'; }).join('');
  fp.innerHTML = '<option value="">All products</option>' + Object.keys(prods).sort().map(function (x) { return '<option value="' + esc(x) + '"' + (x === cp ? ' selected' : '') + '>' + esc(prods[x]) + '</option>'; }).join('');
}
function costLineText() {
  var t = curTarget();
  return 'Target: ' + t.name + ' (' + S.settings.destCode + ')  ·  shipping default $' + t.log + '  ·  duty ' + t.duty + '%  ·  VAT/GST ' + t.vat + '%  ·  extra $' + t.extra + '  ·  margin ' + t.margin + '% (B2C)' + (t.fixed ? ' + $' + t.fixed : '') + (t.sameB2c ? '  ·  B2C = B2B' : (t.marginB2b != null ? '  ·  B2B margin ' + t.marginB2b + '%' + (t.fixedB2b ? ' + $' + t.fixedB2b : '') : '')) + (S.settings.b2bOn === false ? '  ·  B2B OFF' : '');
}
function renderExample(rows) {
  var r = rows.filter(function (x) { return x.calc; })[0], el = $('#howBody'); if (!el) return;
  if (!r) { el.textContent = 'Run a check first. A worked example from your first result with a price will appear here.'; return; }
  var c = r.calc, t = curTarget(), fx = S.settings.fx[r.cur], cfg = srcCfg(srcKey(r)), vat = cfg.vat, ref = effRefund(cfg), m = function (n) { return '$' + money(n); };
  var L = ['Example: ' + r.product + ' from ' + r.country + ' to ' + t.name, '',
    '1. Shop price: ' + r.priceRaw + '  x  rate ' + (Math.round(fx * 10000) / 10000) + ' (' + r.cur + ' to USD)  =  ' + m(c.priceUsd)];
  if (cfg.mode === 'extra') L.push(ref ? '2. The shop adds ' + vat + ' % tax at checkout, but you can get it refunded, so it is not counted:  ' + m(c.netUsd) + '   <- purchase cost' : '2. The shop adds ' + vat + ' % tax at checkout and you cannot get it back:  ' + m(c.priceUsd) + ' x ' + (1 + vat / 100).toFixed(2) + '  =  ' + m(c.netUsd) + '   <- purchase cost');
  else L.push(ref ? '2. Take out ' + vat + ' % VAT (the shop price includes it and you can get it refunded):  ' + m(c.priceUsd) + ' / ' + (1 + vat / 100).toFixed(2) + '  =  ' + m(c.netUsd) + '   <- purchase cost' : '2. The shop price includes ' + vat + ' % VAT that you cannot get back, so the full price is your cost:  ' + m(c.netUsd) + '   <- purchase cost');
  L.push('3. + Shipping from ' + r.country + ' to ' + t.name + ':  ' + m(c.logistics) + '  ->  ' + m(c.netUsd + c.logistics),
    '4. Import duty ' + t.duty + ' % of ' + m(c.netUsd + c.logistics) + '  =  ' + m(c.duty),
    '5. ' + t.name + ' VAT/GST ' + t.vat + ' % of ' + m(c.netUsd + c.logistics + c.duty) + '  =  ' + m(c.vat),
    '6. + Extra expenses  ' + m(c.extra),
    '7. LANDED COST  =  ' + m(c.landed),
    '8. Your margin ' + t.margin + ' %' + (t.fixed ? ' + fixed ' + m(t.fixed) : '') + '  =  ' + m(c.profit) + '  profit',
    '9. SELL PRICE  =  ' + m(c.sell), '',
    'Each source has its own VAT %, "price includes VAT or tax at checkout" and "VAT refund" setting in Sources: shipping & VAT.');
  el.textContent = L.join('\n');
}
function finalCells(r, codes) {
  if (!r.price) return codes.map(function () { return '<td class="num dyn">–</td><td class="num dyn">–</td>'; }).join('');
  return codes.map(function (k) {
    var f = finalFor(r, k), m = function (v) { return v == null ? '–' : f.cur + ' ' + v.toLocaleString(undefined, { maximumFractionDigits: 2 }); };
    return '<td class="num dyn">' + m(f.b2c) + '</td><td class="num dyn">' + m(f.b2b) + '</td>';
  }).join('');
}
function renderResults() {
  fillFilters(); $('#costLine').textContent = costLineText();
  var rows = visibleRows(); renderExample(rows);
  $('#rCount').textContent = rows.length + ' of ' + Object.keys(S.results).length;
  $('#empty').hidden = Object.keys(S.results).length > 0;
  $('#tbody').innerHTML = rows.map(function (r) {
    var c = r.calc;
    var chg = r.prevStatus && r.prevStatus !== r.status ? '<div class="chg">was ' + esc(STATUS_LABEL[r.prevStatus] || r.prevStatus) + '</div>' : '';
    return '<tr title="' + esc(r.note || r.snippet || '') + '"><td>' + esc(r.product) + '</td><td>' + esc(rowCountry(r)) + '<span class="web">' + esc(rowWeb(r)) + '</span></td>' +
      '<td><span class="badge b-' + r.status + '">' + esc(STATUS_LABEL[r.status] || r.status) + '</span>' + chg + (r.listings > 1 ? '<div class="chg">best of ' + r.listings + ' listings</div>' : '') + '</td>' +
      '<td class="num">' + esc(r.priceRaw || '–') + '</td><td class="deliv">' + esc(r.delivery || '–') + '</td>' +
      '<td class="num">' + money(c && c.netUsd) + '</td><td class="num">' + money(c && c.logistics) + '</td><td class="num">' + money(c && c.duty) + '</td>' +
      '<td class="num">' + money(c && c.vat) + '</td><td class="num">' + money(c && c.extra) + '</td><td class="num">' + money(c && c.landed) + '</td><td class="num"><b>' + money(c && c.sell) + '</b></td><td class="num">' + money(c && c.profit) + '</td><td class="num"><b>' + money(c && c.sellB2b) + '</b></td><td class="num">' + money(c && c.profitB2b) + '</td>' +
      '<td>' + ago(r.checkedAt) + '</td><td><a class="open" target="_blank" rel="noopener" href="' + esc(r.url) + '">open</a></td>' + finalCells(r, sellCodes()) + '</tr>';
  }).join('');
  var codes = sellCodes(), hr = $('#tbl thead tr');
  hr.querySelectorAll('th.dyn').forEach(function (x) { x.remove(); });
  codes.forEach(function (k) { var t = S.targets[k]; ['B2C', 'B2B'].forEach(function (ty) { var th = document.createElement('th'); th.className = 'dyn'; th.textContent = 'Final ' + (k === 'GL' ? 'Global' : k) + ' ' + ty; th.title = t.name + ' price in ' + tgtCur(k, t); hr.appendChild(th); }); });
  document.querySelectorAll('th.sortable').forEach(function (th) {
    var on = th.dataset.sort === colSort.key; th.classList.toggle('asc', on && colSort.dir === 1); th.classList.toggle('desc', on && colSort.dir === -1);
    th.querySelector('.si').textContent = on ? (colSort.dir === 1 ? '▲' : '▼') : '⇅';
  });
  renderSummary();
}
function renderSummary() {
  var all = Object.keys(S.results).map(function (k) { return S.results[k]; });
  var cnt = {}; all.forEach(function (r) { cnt[r.status] = (cnt[r.status] || 0) + 1; });
  var html = Object.keys(cnt).map(function (k) { return '<span class="pill">' + esc(STATUS_LABEL[k] || k) + ': <b>' + cnt[k] + '</b></span>'; }).join('');
  var cs = costSettings(), best = {};
  all.forEach(function (r) {
    if (r.status !== 'IN_STOCK' || !r.price) return;
    var c = rowCalc(r, cs), pk = String(r.product).toLowerCase();
    if (c && (!best[pk] || c.sell < best[pk].sell)) best[pk] = { sell: c.sell, product: r.product, country: r.country };
  });
  Object.keys(best).forEach(function (k) { html += '<span class="pill">Cheapest in stock – ' + esc(best[k].product) + ': <b>' + esc(best[k].country) + ' $' + money(best[k].sell) + '</b></span>'; });
  $('#summary').innerHTML = html;
}

/* ---------- injected page functions (must be self-contained) ---------- */
function extractPage() {
  var main = document.querySelector('main') || document.body;
  var text = (main.innerText || '').slice(0, 9000);
  var btns = Array.prototype.slice.call(document.querySelectorAll('button,[role="button"],a[role="button"]')).map(function (el) {
    return { text: ((el.innerText || el.getAttribute('aria-label') || '') + '').trim().slice(0, 80), disabled: el.disabled === true || el.getAttribute('aria-disabled') === 'true' };
  }).filter(function (b) { return b.text && b.text.length < 60; }).slice(0, 250);
  var body = (document.body.innerText || '').toLowerCase().slice(0, 4000), title = (document.title || '').toLowerCase();
  var blocked = /captcha|are you a robot|confirm you.?re human|security check|unusual traffic|verify you are human/.test(body) ||
    (/log ?in|sign ?in/.test(title) && body.length < 800) || /\/login|checkpoint/.test(location.pathname);
  var notFound = /page (not found|isn.t available)|not found|404/.test(title) || (body.length < 400 && /page (not found|isn.t available)|404/.test(body));
  return { title: document.title, url: location.href, text: text, buttons: btns, blocked: blocked, notFound: notFound };
}
function discoverPage() {
  var out = {};
  Array.prototype.slice.call(document.querySelectorAll('a[href*="/ai-glasses/"]')).forEach(function (a) {
    var m = a.getAttribute('href').match(/\/ai-glasses\/([a-z0-9-]+)\/?(?:[?#].*)?$/i);
    if (!m) return;
    var name = ((a.getAttribute('aria-label') || a.innerText || '') + '').replace(/\s+/g, ' ').trim().slice(0, 60);
    if (!out[m[1]] || (name && name.length > (out[m[1]] || '').length)) out[m[1]] = name;
  });
  return out;
}
function amazonPage() {
  var t = function (s) { var e = document.querySelector(s); return e ? ((e.innerText || e.textContent || '') + '').replace(/\s+/g, ' ').trim() : ''; };
  var body = ((document.body && document.body.innerText) || '').slice(0, 3000).toLowerCase();
  var captcha = !!document.querySelector('form[action*="validateCaptcha"]') || /enter the characters you see|type the characters you see|robot check|not a robot/.test(body);
  var atc = document.querySelector('#add-to-cart-button, input[name="submit.add-to-cart"], #buy-now-button');
  var avail = t('#availability') + ' ' + t('#outOfStock') + ' ' + t('#availability_feature_div');
  var title = t('#productTitle');
  var price = t('#corePrice_feature_div .a-price .a-offscreen') || t('#apex_desktop .a-price .a-offscreen') || t('#corePriceDisplay_desktop_feature_div .a-price .a-offscreen') || (title ? t('.a-price .a-offscreen') : '');
  var del = t('#mir-layout-DELIVERY_BLOCK') || t('#deliveryBlockMessage') || t('#delivery-message');
  var notFound = !title && !captcha && (/page not found|looking for something|couldn.t find that page|sorry/.test((document.title || '').toLowerCase()) || !!document.querySelector('img[alt*="dogs"], #g'));
  return { title: title || document.title, url: location.href, atc: !!atc, atcDisabled: !!(atc && atc.disabled),
    preorder: !!document.querySelector('#pre-order-button, #submit\\.preorder') || /pre-?order/i.test(t('#add-to-cart-button') + ' ' + avail),
    outOfStock: !!document.querySelector('#outOfStock') || /out of stock|currently unavailable|temporarily out|non disponible|nicht verf|no disponible|non disponibile|niet beschikbaar|dostępn|stokta yok|غير متوفر|mevcut de/i.test(avail),
    unavailable: /currently unavailable|unavailable/i.test(avail), seeAll: !!document.querySelector('#buybox-see-all-buying-choices, #buybox-see-all-buying-choices-announce'),
    priceText: price, delivery: del.slice(0, 220), seller: t('#merchantInfoFeature_feature_div').slice(0, 140), blocked: captcha, notFound: notFound, text: body.slice(0, 600) };
}
function amazonSearchPage() {
  var out = [];
  Array.prototype.slice.call(document.querySelectorAll('[data-component-type="s-search-result"]')).forEach(function (c) {
    var asin = c.getAttribute('data-asin'); if (!asin) return;
    if (/sponsored/i.test((c.querySelector('.puis-sponsored-label-text, .s-label-popover-default') || {}).innerText || '')) return;
    var img = c.querySelector('img.s-image'), h = c.querySelector('h2');
    var title = ((img && img.getAttribute('alt')) || (h && h.innerText) || '').replace(/\s+/g, ' ').trim();
    var pr = c.querySelector('.a-price .a-offscreen');
    if (title) out.push({ id: asin, title: title.slice(0, 160), priceText: pr ? pr.textContent.trim() : '', url: location.origin + '/dp/' + asin });
  });
  return out.slice(0, 12);
}
function genericSearchPage() {
  var out = [], seen = {}, re = /(?:[$€£₹¥]|AED|USD|EUR|GBP|SAR|INR|CAD|AUD)\s?\d[\d.,]*|\d[\d.,]*\s?(?:€|AED|SAR|zł|kr)/;
  Array.prototype.slice.call(document.querySelectorAll('a[href]')).forEach(function (a) {
    var href = a.href, txt = ((a.innerText || a.getAttribute('aria-label') || a.title || '') + '').replace(/\s+/g, ' ').trim();
    if (!/^https?:/.test(href) || seen[href] || txt.length < 12 || txt.length > 160) return;
    var box = a, pt = '';
    for (var i = 0; i < 5 && box; i++) { var m = re.exec(box.innerText || ''); if (m) { pt = m[0]; break; } box = box.parentElement; }
    if (!pt) return;
    seen[href] = 1; out.push({ id: '', title: txt, priceText: pt, url: href });
  });
  return out.slice(0, 15);
}
async function shopAllPage() {
  var wait = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };
  for (var i = 0; i < 10; i++) { window.scrollTo(0, document.body.scrollHeight); await wait(700); }
  var out = {};
  Array.prototype.slice.call(document.querySelectorAll('a[href*="/ai-glasses/"]')).forEach(function (a) {
    var m = (a.getAttribute('href') || '').match(/\/ai-glasses\/([a-z0-9-]+)\/?(?:[?#].*)?$/i); if (!m) return;
    var t = ((a.innerText || a.getAttribute('aria-label') || '') + '').replace(/\s+/g, ' ').trim();
    if (!/\d/.test(t) || !/colou?rs?|from/i.test(t)) return; // product cards show colours + price; menu links do not
    if (!out[m[1]]) out[m[1]] = t.slice(0, 160);
  });
  return out;
}
async function variantsFullPage() {
  var wait = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };
  var slugOf = function () { var m = location.pathname.match(/\/ai-glasses\/([a-z0-9-]+)/i); return m ? m[1].toLowerCase() : ''; };
  var lab = function (el) { return ((el.getAttribute('aria-label') || el.innerText || '') + '').replace(/\s+/g, ' ').trim().slice(0, 200); };
  var vis = function (e) { var r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
  var res = { start: slugOf(), found: {}, sizes: [] };
  var allGroups = function () { return Array.prototype.slice.call(document.querySelectorAll('[role="radiogroup"]')); };
  allGroups().forEach(function (g) { var n = g.getAttribute('aria-label') || ''; if (/size|fit/i.test(n)) { Array.prototype.slice.call(g.querySelectorAll('[role="radio"]')).forEach(function (r) { var x = lab(r), t = n + ': ' + x; if (x && res.sizes.indexOf(t) === -1) res.sizes.push(t); }); } });
  var isColour = function (g) { var n = g.getAttribute('aria-label') || ''; if (/thumbnail|feature|size|fit/i.test(n)) return false; var r = g.querySelector('[role="radio"]'); return /style|colou?r|lens/i.test(n + ' ' + (r ? lab(r) : '')); };
  var cg = allGroups().filter(isColour).filter(vis)[0] || allGroups().filter(isColour)[0];
  if (!cg) return res;
  var labels = [];
  Array.prototype.slice.call(cg.querySelectorAll('[role="radio"]')).forEach(function (r) { var l = lab(r); if (l && labels.indexOf(l) === -1) labels.push(l); if (r.getAttribute('aria-checked') === 'true' && l && !res.found[res.start]) res.found[res.start] = l; });
  for (var i = 0; i < labels.length; i++) { // the page re-draws after each click, so find the option again every time
    var l = labels[i], before = slugOf();
    var el = Array.prototype.slice.call(document.querySelectorAll('[role="radio"]')).filter(function (r) { return lab(r) === l && vis(r); })[0];
    if (!el) continue;
    if (el.getAttribute('aria-checked') === 'true') { if (!res.found[slugOf()]) res.found[slugOf()] = l; continue; }
    try { el.click(); } catch (e) {}
    for (var k = 0; k < 20; k++) { await wait(150); if (slugOf() !== before) break; }
    await wait(300);
    var sl = slugOf(); if (sl && !res.found[sl]) res.found[sl] = l;
  }
  return res;
}
function helpPage() { return { text: (document.querySelector('main') || document.body).innerText.slice(0, 20000) }; }

/* ---------- tab engine ---------- */
var running = false, stopFlag = false, workWin = null, winMaking = null, allWins = [], idleT = null;
// One shared work window: parallel checks wait for the same window instead of each opening their own.
async function ensureWindow() {
  if (workWin) { try { await chrome.windows.get(workWin); return workWin; } catch (e) { workWin = null; } }
  if (!winMaking) {
    winMaking = (async function () {
      try { var w = await chrome.windows.create({ url: 'about:blank', focused: false, width: 1100, height: 800 }); workWin = w.id; allWins.push(w.id); return workWin; }
      finally { winMaking = null; }
    })();
  }
  return winMaking;
}
var activeTabs = 0;
async function closeWindow() {
  if (activeTabs > 0) return;
  var ids = allWins.slice(); allWins = []; if (workWin && ids.indexOf(workWin) === -1) ids.push(workWin); workWin = null;
  for (var i = 0; i < ids.length; i++) { try { await chrome.windows.remove(ids[i]); } catch (e) {} }
}
// Safety net: if nothing has used the work window for a while, close it (and any stray ones).
function scheduleIdleClose() { clearTimeout(idleT); idleT = setTimeout(function () { if (activeTabs === 0 && !running) closeWindow(); }, 8000); }
async function waitComplete(tabId, ms) {
  var t0 = Date.now();
  while (Date.now() - t0 < ms) {
    try { var t = await chrome.tabs.get(tabId); if (t.status === 'complete') return t; } catch (e) { return null; }
    await sleep(400);
  }
  return null;
}
async function withTab(url, fn) {
  var winId = await ensureWindow();
  var tab = await chrome.tabs.create({ windowId: winId, url: url, active: false });
  activeTabs++;
  try { return await fn(tab.id); }
  finally { activeTabs--; try { await chrome.tabs.remove(tab.id); } catch (e) {} scheduleIdleClose(); }
}
async function inject(tabId, func) {
  try { var r = await chrome.scripting.executeScript({ target: { tabId: tabId }, func: func }); return r && r[0] ? r[0].result : null; }
  catch (e) { return null; }
}

async function checkOne(country, product) {
  var url = product.url || M.buildUrl(country.cc, product.slug);
  var row = { key: product.key || (country.cc + '|' + product.slug), source: country.site ? country.site.name : 'Meta.com', site: country.site ? country.site.id : undefined, srcVat: country.site ? Number(country.site.vat) || 0 : undefined, cc: country.cc, country: country.name, slug: product.slug, product: product.name, url: url,
    status: 'ERROR', priceRaw: '', price: null, cur: country.cur, delivery: '', snippet: '', checkedAt: Date.now(), note: '' };
  var timeoutMs = Math.max(8, S.settings.timeoutSec) * 1000;
  if (country.site && country.site.kind === 'amazon') {
    row.kind = 'amazon';
    await withTab(url, async function (tabId) {
      await waitComplete(tabId, 30000);
      var t0 = Date.now(), d = null;
      while (Date.now() - t0 < timeoutMs && !stopFlag) {
        await sleep(1200);
        var r = await inject(tabId, amazonPage); if (!r) continue; d = r;
        if (r.blocked || r.notFound) break;
        if (r.title && (r.atc || r.outOfStock || r.unavailable || r.seeAll || r.preorder) && (r.priceText || !r.atc)) break;
      }
      if (!d) { row.note = 'Page did not load or could not be read'; return; }
      row.finalUrl = d.url; row.snippet = (d.title || '').slice(0, 200); row.siteTitle = d.title;
      if (d.blocked) { row.status = 'BLOCKED'; row.note = 'Amazon showed a robot check. Open it in your normal browser, complete it, then check again.'; return; }
      if (d.notFound) { row.status = 'ERROR'; row.note = 'Page not found – the ASIN may be wrong for this Amazon site'; return; }
      row.status = M.classifyAmazon(d);
      var pr = M.findPriceLoose(d.priceText); if (pr) { row.priceRaw = d.priceText.slice(0, 30); row.price = pr.value; }
      row.delivery = d.delivery || ''; if (d.seller) row.note = d.seller;
      if (row.status === 'UNKNOWN') row.note = 'Unclear: no Add to cart or stock message found. ' + row.note;
    });
    return row;
  }
  await withTab(url, async function (tabId) {
    await waitComplete(tabId, 30000);
    var t0 = Date.now(), best = null;
    while (Date.now() - t0 < timeoutMs && !stopFlag) {
      await sleep(1200);
      var res = await inject(tabId, extractPage);
      if (!res) continue;
      var status = M.classify(res.buttons, res.text), price = M.findPrice(res.text);
      best = { res: res, status: status, price: price };
      if (res.blocked || res.notFound) break;
      if (status !== 'UNKNOWN' && (price || status === 'NOT_SOLD' || status === 'OUT_OF_STOCK')) break;
    }
    if (!best) { row.note = 'Page did not load or could not be read'; return; }
    var res2 = best.res;
    row.snippet = (res2.text || '').replace(/\s+/g, ' ').slice(0, 300);
    row.finalUrl = res2.url;
    if (res2.blocked) { row.status = 'BLOCKED'; row.note = (country.site ? 'The website' : 'Meta') + ' showed a check or login page'; return; }
    if (res2.notFound) { row.status = 'ERROR'; row.note = 'Page not found – the product address may be wrong' + (country.site ? '' : ' for this country'); return; }
    if (!product.url && M.pathCountry(res2.url) !== country.cc) { row.status = 'REDIRECTED'; row.note = 'Meta redirected to the ' + M.pathCountry(res2.url) + ' store'; return; }
    row.status = best.status;
    if (best.status === 'UNKNOWN') row.note = 'Unclear. Buttons seen: ' + (res2.buttons || []).slice(0, 10).map(function (b) { return b.text; }).join(' / ');
    if (best.price) { row.priceRaw = best.price.raw; row.price = best.price.value; }
    row.delivery = M.findDelivery(res2.text);
  });
  return row;
}

async function runChecks(force) {
  if (running) return;
  S.settings.lastAuto = Date.now();
  var items = [];
  S.selProducts.forEach(function (slug) {
    var p = allProducts().find(function (x) { return x[0] === slug; }); if (!p) return;
    S.selCountries.forEach(function (cc) {
      var c = countryInfo(cc); if (!c) return;
      var key = cc + '|' + slug, ex = S.results[key];
      var fresh = ex && !force && Date.now() - ex.checkedAt < S.settings.cacheHours * 3600e3 && ['ERROR', 'BLOCKED', 'UNKNOWN'].indexOf(ex.status) === -1;
      if (!fresh) items.push({ country: c, product: { slug: slug, name: p[1] } });
    });
  });
  S.selSites.forEach(function (id) {
    var site = S.sites.find(function (x) { return x.id === id; }); if (!site) return;
    site.urls.forEach(function (it) {
      var key = itemKey(site, it), ex = S.results[key];
      var fresh = ex && !force && Date.now() - ex.checkedAt < S.settings.cacheHours * 3600e3 && ['ERROR', 'BLOCKED', 'UNKNOWN'].indexOf(ex.status) === -1;
      if (!fresh) items.push({ country: { cc: site.cc || 'XX', name: siteLabel(site), cur: site.cur, site: site }, product: { slug: it.url, name: it.name, url: it.url, key: key, ref: it } });
    });
  });
  if (!items.length) { banner('Nothing to check: everything ticked already has a fresh result (use Force re-check), or nothing is ticked.'); return; }
  running = true; stopFlag = false; banner('');
  $('#btnCheck').disabled = true; $('#btnForce').disabled = true; $('#btnStop').hidden = false; $('#progressWrap').hidden = false;
  var done = 0, total = items.length, blocked = 0, idx = 0;
  function prog() { $('#progressBar').style.width = (done / total * 100) + '%'; $('#progressText').textContent = done + ' / ' + total + ' checked'; }
  prog();
  async function worker() {
    while (!stopFlag) {
      var i = idx++; if (i >= items.length) return;
      var it = items[i], row;
      try {
        row = await checkOne(it.country, it.product);
        var ref = it.product.ref, st = it.country.site;
        if (ref && st && ref.q && st.searchUrl && row.status === 'ERROR' && /not found/i.test(row.note || '')) { // the page moved: find the listing again by its title
          var nu = await refindListing(st, ref);
          if (nu && nu !== ref.url) { if (!ref.uid) ref.uid = ref.url; ref.url = nu; it.product.url = nu; row = await checkOne(it.country, it.product); row.key = it.product.key; row.note = ((row.note || '') + ' (link refreshed by Find listings)').trim(); }
        }
      }
      catch (e) { row = { key: it.product.key || (it.country.cc + '|' + it.product.slug), source: it.country.site ? it.country.site.name : 'Meta.com', site: it.country.site ? it.country.site.id : undefined, srcVat: it.country.site ? Number(it.country.site.vat) || 0 : undefined, cc: it.country.cc, country: it.country.name, slug: it.product.slug, product: it.product.name, url: it.product.url || M.buildUrl(it.country.cc, it.product.slug), status: 'ERROR', note: String(e && e.message || e), checkedAt: Date.now(), price: null, priceRaw: '', delivery: '' }; }
      if (stopFlag && row.note === 'Page did not load or could not be read') continue;
      var prev = S.results[row.key]; if (prev && prev.status !== 'ERROR') row.prevStatus = prev.status; else if (prev) row.prevStatus = prev.prevStatus;
      S.results[row.key] = row; done++; prog(); renderResults(); save();
      if (row.status === 'BLOCKED') { blocked++; if (blocked >= 2) { stopFlag = true; banner('A website is showing a check or login page. Open it in your normal browser, complete it, then press Check selected again. Finished rows are kept.'); } } else blocked = 0;
    }
  }
  var n = Math.max(1, Math.min(12, Number(S.settings.concurrency) || 5)), ws = [];
  for (var k = 0; k < n; k++) ws.push(worker());
  await Promise.all(ws);
  await closeWindow();
  running = false; $('#btnCheck').disabled = false; $('#btnForce').disabled = false; $('#btnStop').hidden = true;
  if (!$('#banner').textContent) banner(stopFlag ? 'Stopped. Finished rows are kept.' : 'Done. ' + done + ' checked.');
  renderResults(); save();
  if (S.settings.autoPush && S.settings.wpKey && S.settings.wpUrl) await wpPush(true);
}

function banner(msg) { var b = $('#banner'); b.textContent = msg; b.hidden = !msg; }

/* ---------- discover products / refresh countries ---------- */
async function discoverProducts() {
  var first = S.selCountries[0] || 'US';
  banner('Reading the product list from the ' + first + ' store…');
  var found = await withTab(M.buildUrl(first, '').replace(/\/\/$/, '/'), async function (tabId) {
    await waitComplete(tabId, 30000);
    var best = {};
    for (var i = 0; i < 10; i++) { await sleep(1500); var r = await inject(tabId, discoverPage); if (r && Object.keys(r).length >= Object.keys(best).length) best = r; if (Object.keys(best).length >= 3 && i > 3) break; }
    return best;
  });
  await closeWindow();
  var added = 0, known = allProducts().map(function (p) { return p[0]; });
  Object.keys(found || {}).forEach(function (slug) {
    if (/^(compare|faq|support|accessories|accessibility|prescription|bluetooth-glasses|help|shop|all|shop-all|privacy|learn|refurbished)$/.test(slug)) return;
    if (known.indexOf(slug) !== -1) { var ex = S.customProducts.find(function (p) { return p.slug === slug; }); if (ex) ex.discovered = true; return; }
    S.customProducts.push({ slug: slug, name: found[slug] || slug, discovered: true });
    S.selProducts.push(slug); added++;
  });
  renderProducts(); save();
  banner(Object.keys(found || {}).length ? 'Found ' + Object.keys(found).length + ' product links, ' + added + ' new. Untick anything that is not a glasses model.' : 'Could not read product links (page may not have finished loading). Try again, or add slugs by hand.');
}
var ALIAS = { GB: ['united kingdom', 'uk', 'great britain'], AE: ['united arab emirates', 'uae'], US: ['united states', 'usa', 'united states of america'], KR: ['south korea', 'korea'], NL: ['netherlands', 'the netherlands'] };
async function refreshCountries() {
  banner('Reading Meta’s supported-countries page…');
  var res = await withTab(D.helpUrl, async function (tabId) {
    await waitComplete(tabId, 30000);
    for (var i = 0; i < 8; i++) { await sleep(1500); var r = await inject(tabId, helpPage); if (r && /countries/i.test(r.text) && r.text.length > 300) return r; }
    return null;
  });
  await closeWindow();
  if (!res) { banner('Could not read Meta’s country page. Try again in a moment.'); return; }
  var lines = res.text.split(/\n+/).map(function (l) { return l.replace(/^[\s•\-–*]+/, '').trim(); }).filter(Boolean);
  var start = lines.findIndex(function (l) { return /following countries|available and supported/i.test(l); });
  var cands = [];
  for (var i = start + 1; i < lines.length; i++) { if (lines[i].length > 40) break; if (/^[A-Z][A-Za-z .'’&-]{2,30}$/.test(lines[i])) cands.push(lines[i]); }
  S.listedByMeta = {}; var unknown = [];
  cands.forEach(function (name) {
    var n = name.toLowerCase(), hit = allCountries().find(function (c) { return c[1].toLowerCase() === n || (ALIAS[c[0]] || []).indexOf(n) !== -1; });
    if (hit) S.listedByMeta[hit[0]] = true; else unknown.push(name);
  });
  Object.keys(S.listedByMeta).forEach(function (cc) { if (S.selCountries.indexOf(cc) === -1) S.selCountries.push(cc); });
  renderCountries(); save();
  banner('Meta lists ' + cands.length + ' countries; ' + Object.keys(S.listedByMeta).length + ' matched and ticked.' + (unknown.length ? ' Not in the built-in list (use + Add country): ' + unknown.join(', ') + '.' : ''));
}

/* ---------- export ---------- */
function download(name, mime, content) {
  var a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([content], { type: mime })); a.download = name; document.body.appendChild(a); a.click(); a.remove();
}
function stamp() { return new Date().toISOString().slice(0, 16).replace(/[:T]/g, '-'); }
function finalHeads() { var o = []; sellCodes().forEach(function (k) { var t = S.targets[k], c = tgtCur(k, t); o.push('Final ' + k + ' B2C ' + c, 'Final ' + k + ' B2B ' + c); }); return o; }
function finalVals(r) { var o = []; sellCodes().forEach(function (k) { if (!r.price) { o.push('', ''); return; } var f = finalFor(r, k); o.push(f.b2c, f.b2b); }); return o; }
function exportCsv() {
  var rows = visibleRows();
  var csv = M.toCsv(['Source', 'Product', 'Country', 'Code', 'Status', 'Price local', 'Currency', 'Delivery', 'Net USD', 'Shipping USD', 'Duty USD', 'VAT USD', 'Extra USD', 'Landed USD', 'Sell B2C USD', 'Profit B2C USD', 'Sell B2B USD', 'Profit B2B USD', 'Checked', 'URL', 'Note', 'Page text sample'].concat(finalHeads()),
    rows.map(function (r) { var c = r.calc || {}; return [rowWeb(r), r.product, rowCountry(r), r.cc, STATUS_LABEL[r.status] || r.status, r.price, r.cur, r.delivery, c.netUsd, c.logistics, c.duty, c.vat, c.extra, c.landed, c.sell, c.profit, c.sellB2b, c.profitB2b, new Date(r.checkedAt).toISOString(), r.url, r.note, r.snippet].concat(finalVals(r)); }));
  download('meta-stock-' + stamp() + '.csv', 'text/csv', '﻿' + csv);
}
function exportXlsx() {
  var rows = visibleRows();
  var head = ['Source', 'Product', 'Country / site', 'Code', 'Status', 'Price local', 'Currency', 'Delivery', 'Net USD', 'Shipping USD', 'Duty USD', 'VAT USD', 'Extra USD', 'Landed USD', 'Sell B2C USD', 'Profit B2C USD', 'Sell B2B USD', 'Profit B2B USD', 'Checked', 'URL', 'Note'].concat(finalHeads());
  var data = [head].concat(rows.map(function (r) { var c = r.calc || {};
    return [rowWeb(r), r.product, rowCountry(r), r.cc, STATUS_LABEL[r.status] || r.status, r.price, r.cur, r.delivery, c.netUsd, c.logistics, c.duty, c.vat, c.extra, c.landed, c.sell, c.profit, c.sellB2b, c.profitB2b, new Date(r.checkedAt).toLocaleString(), r.url, r.note].concat(finalVals(r)); }));
  var st = S.settings, tg = curTarget(), as = [['Setting', 'Value'], ['Target country', tg.name + ' (' + st.destCode + ')'], ['Import duty %', tg.duty], ['GST / VAT %', tg.vat], ['Extra expenses USD/unit', tg.extra], ['Profit margin %', tg.margin],
    ['Default shipping USD/unit', tg.log], ['VAT refund possible by default', st.includesVat ? 'Yes' : 'No'], ['Exchange rates updated', S.fxLive && S.fxLive.date ? S.fxLive.date : 'never (placeholders)'], ['Note', 'Duty, VAT, shipping and extras are placeholders until confirmed']];
  Object.keys(st.fx).sort().forEach(function (k) { as.push(['USD per 1 ' + k, st.fx[k]]); });
  Object.keys(tg.ship).sort().forEach(function (k) { as.push(['Shipping USD from ' + k, tg.ship[k]]); });
  var bytes = XLSX_LITE.build([{ name: 'Results', rows: data }, { name: 'Assumptions', rows: as }]);
  download('stock-check-' + stamp() + '.xlsx', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', bytes);
}
function exportList() {
  var base = {}; D.products.forEach(function (p) { base[p[0]] = p[1]; });
  var ov = S.nameOverride || {};
  var prod = [['Model (group)', 'Variant / product name', 'Meta page name (slug)', 'Meta page (selected country)', 'Sizes / fit (note)', 'Ticked for checks', 'Renamed by you', 'Original name', 'Imported from', 'Type']];
  var cc = (S.selCountries[0] || 'IN');
  allProducts().forEach(function (p) {
    var c = S.customProducts.find(function (x) { return x.slug === p[0]; }) || {};
    var orig = c.name && ov[p[0]] ? c.name : (base[p[0]] || '');
    prod.push([groupOf(p), p[1], p[0], M.buildUrl(cc, p[0]), c.opts || '', S.selProducts.indexOf(p[0]) !== -1 ? 'Yes' : 'No', ov[p[0]] ? 'Yes' : '', ov[p[0]] ? orig : '', c.src || '', c.variantOf ? 'Variant' : (c.discovered ? 'Imported' : (p[3] ? 'Added by hand' : 'Built-in'))]);
  });
  var web = [['Website', 'Kind', 'Continent', 'Country', 'Currency', 'VAT %', 'Price shown', 'VAT refund', 'Ticked', 'Search link', 'Page address pattern', 'Listings']];
  var lst = [['Website', 'Product name', 'Page link', 'ID (ASIN)', 'Search words saved', 'Title found']];
  S.sites.forEach(function (x) {
    var cfg = srcCfg('site:' + x.id);
    web.push([x.name, x.kind === 'amazon' ? 'Amazon' : 'Website', x.region || '', x.cc || '', x.cur || '', cfg.vat, cfg.mode === 'extra' ? 'Tax added at checkout' : 'Includes VAT', cfg.refund == null ? 'Default (' + (S.settings.includesVat ? 'Yes' : 'No') + ')' : (cfg.refund ? 'Yes' : 'No'), S.selSites.indexOf(x.id) !== -1 ? 'Yes' : 'No', x.searchUrl || '', x.pattern || '', x.urls.length]);
    x.urls.forEach(function (u) { lst.push([x.name, u.name, u.url, u.id || '', u.q || '', u.title || '']); });
  });
  var ctry = [['Country', 'Code', 'Currency', 'VAT % in price', 'Price shown', 'VAT refund', 'Ticked']];
  allCountries().forEach(function (c) { var cfg = srcCfg(c[0]); ctry.push(['meta.com/' + c[0].toLowerCase() + ' ' + c[1], c[0], c[3], cfg.vat, cfg.mode === 'extra' ? 'Tax added at checkout' : 'Includes VAT', cfg.refund == null ? 'Default' : (cfg.refund ? 'Yes' : 'No'), S.selCountries.indexOf(c[0]) !== -1 ? 'Yes' : 'No']); });
  var bytes = XLSX_LITE.build([{ name: 'Products', rows: prod }, { name: 'Websites', rows: web }, { name: 'Website listings', rows: lst }, { name: 'Meta countries', rows: ctry }]);
  download('stock-checker-list-' + stamp() + '.xlsx', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', bytes);
  banner('Exported ' + (prod.length - 1) + ' products, ' + (web.length - 1) + ' websites and ' + (lst.length - 1) + ' listings, with your current names and settings.');
}
/* ---------- costing template / import (Excel) ---------- */
function allSources() {
  var rows = [];
  allCountries().slice().sort(function (x, y) { return regionIdx(x[2]) - regionIdx(y[2]) || x[0].localeCompare(y[0]); }).forEach(function (c) { rows.push({ key: c[0], label: 'meta.com/' + c[0].toLowerCase() }); });
  S.sites.forEach(function (x) { rows.push({ key: 'site:' + x.id, label: x.name }); });
  return rows;
}
function exportCosting() {
  var tg = [['Target code', 'Target country', 'Import duty %', 'VAT / GST %', 'Extra expenses $ per unit', 'Fixed profit $ per unit', 'Profit margin % (B2C)', 'Default shipping $ per unit', 'B2B margin % (blank = same as B2C)', 'B2B fixed profit $ (blank = same)', 'B2C = B2B (Yes/No)', 'Website(s)', 'Website shows (B2C/B2B)', 'Price currency', 'Round (Yes/No)', 'Send to WordPress (Yes/No)', 'Selling country (Yes/No)']];
  Object.keys(S.targets).forEach(function (k) { var t = S.targets[k]; tg.push([k, t.name, t.duty, t.vat, t.extra, t.fixed || 0, t.margin, t.log, t.marginB2b == null ? '' : t.marginB2b, t.fixedB2b == null ? '' : t.fixedB2b, t.sameB2c ? 'Yes' : 'No', t.host || '', t.type === 'B2B' ? 'B2B' : 'B2C', t.cur || '', t.round ? 'Yes' : 'No', t.push ? 'Yes' : 'No', t.sell ? 'Yes' : 'No']); });
  var src = allSources(), sh = [['Target code', 'Source (meta.com/xx or website name)', 'Shipping $ per unit (blank = use default)']];
  Object.keys(S.targets).forEach(function (k) {
    var t = S.targets[k];
    src.forEach(function (r) { if (k === S.settings.destCode || t.ship[r.key] != null) sh.push([k, r.label, t.ship[r.key] == null ? '' : t.ship[r.key]]); });
  });
  var vt = [['Source (meta.com/xx or website name)', 'VAT % in the shown price', 'Price shown (Includes VAT / Tax at checkout)', 'VAT refund (Yes / No / blank = default)']];
  src.forEach(function (r) { var cfg = srcCfg(r.key); vt.push([r.label, cfg.vat, cfg.mode === 'extra' ? 'Tax at checkout' : 'Includes VAT', cfg.refund == null ? '' : (cfg.refund ? 'Yes' : 'No')]); });
  var bt = [['Brand', 'B2B on (Yes/No)', 'B2C on (Yes/No)', 'B2B margin % (blank = target)', 'B2B fixed profit $', 'B2C margin % (blank = target)', 'B2C fixed profit $', 'B2C = B2B (Yes/No)', 'Extra $ per unit', 'Import duty %', 'Shipping $ per unit']];
  brandList().forEach(function (b) { var c = (S.brands && S.brands[b.name]) || {}, g = function (f) { return c[f] == null ? '' : c[f]; };
    bt.push([b.name, c.b2b === false ? 'No' : 'Yes', c.b2c === false ? 'No' : 'Yes', g('mB2b'), g('fB2b'), g('mB2c'), g('fB2c'), c.same ? 'Yes' : 'No', g('extra'), g('duty'), g('log')]); });
  var fx = [['Currency', 'USD per 1 unit (your own rate)']];
  Object.keys(S.settings.fx).sort().forEach(function (k) { fx.push([k, S.settings.fx[k]]); });
  var rd = [['How to use'], ['1. Edit the numbers in the sheets Targets, Shipping, Sources and Rates. Keep the first row (headings) and the first column values.'],
    ['2. Targets: one row per target country. Add a row with a new code to add a country. Blank cells keep the current value.'],
    ['3. Shipping: one row per target + source. Source can be meta.com/de, DE, or a website name (amazon.ae). Rows you delete are left unchanged.'],
    ['4. Sources: VAT % and whether the price includes VAT or tax is added at checkout, and if you can get the VAT refunded.'],
    ['5. Rates: only rows you put here are used; they become your own fixed rates (not overwritten by live rates).'],
    ['6. Brands: switch B2B / B2C on or off for a brand (Yes/No) and give it its own margin, duty, extra and shipping. Blank = use the Targets numbers.'],
    ['7. Save as .xlsx and press Import costing (Excel) in the extension.']];
  var bytes = XLSX_LITE.build([{ name: 'Targets', rows: tg }, { name: 'Shipping', rows: sh }, { name: 'Sources', rows: vt }, { name: 'Brands', rows: bt }, { name: 'Rates', rows: fx }, { name: 'Read me', rows: rd }]);
  download('costing-template-' + stamp() + '.xlsx', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', bytes);
  banner('Costing sheet downloaded: fill it in and press Import costing (Excel).');
}
function sheetBy(sheets, name) { var k = Object.keys(sheets).find(function (x) { return x.toLowerCase().replace(/\s+/g, '') === name; }); return k ? sheets[k] : null; }
function numOrNull(v) { if (v === '' || v == null) return null; var n = Number(String(v).replace(/[^0-9.\-]/g, '')); return isFinite(n) && String(v).trim() !== '' ? n : null; }
function resolveSource(label) {
  var x = String(label || '').trim(), l = x.toLowerCase(); if (!l) return null;
  var m = /^(?:meta\.com\/)?([a-z]{2})$/i.exec(l.replace(/\s.*$/, ''));
  if (m && countryInfo(m[1].toUpperCase())) return m[1].toUpperCase();
  if (l.indexOf('site:') === 0 && siteById(x.slice(5))) return x;
  var st = S.sites.find(function (y) { return y.name.toLowerCase() === l || y.name.toLowerCase().replace(/^www\./, '') === l.replace(/^www\./, ''); });
  return st ? 'site:' + st.id : null;
}
function importCosting(sheets) {
  var n = { targets: 0, ship: 0, src: 0, fx: 0 }, bad = [];
  var T = sheetBy(sheets, 'targets');
  if (T) T.slice(1).forEach(function (r) {
    var code = String(r[0] || '').trim().toUpperCase(); if (!/^[A-Z]{2}$/.test(code)) return;
    var t = S.targets[code] = S.targets[code] || { name: String(r[1] || code), duty: 0, vat: 0, extra: 0, fixed: 0, margin: 15, log: 3, ship: {} };
    if (r[1]) t.name = String(r[1]);
    [[2, 'duty'], [3, 'vat'], [4, 'extra'], [5, 'fixed'], [6, 'margin'], [7, 'log']].forEach(function (f) { var v = numOrNull(r[f[0]]); if (v != null) t[f[1]] = v; });
    [[8, 'marginB2b'], [9, 'fixedB2b']].forEach(function (f) { if (r.length > f[0]) { var v = numOrNull(r[f[0]]); if (v == null) delete t[f[1]]; else t[f[1]] = v; } });
    if (r.length > 10 && String(r[10] || '').trim()) t.sameB2c = /^(y|yes|true|1)/i.test(String(r[10]).trim());
    var yn2 = function (v) { return /^(y|yes|true|1)/i.test(String(v || '').trim()); };
    if (r.length > 11 && String(r[11] || '').trim() !== '') setTarget(code, 'host', r[11]);
    if (r.length > 12 && String(r[12] || '').trim()) setTarget(code, 'type', String(r[12]).trim().toUpperCase());
    if (r.length > 13 && String(r[13] || '').trim()) setTarget(code, 'cur', r[13]);
    if (r.length > 14 && String(r[14] || '').trim()) t.round = yn2(r[14]);
    if (r.length > 15 && String(r[15] || '').trim()) t.push = yn2(r[15]);
    if (r.length > 16 && String(r[16] || '').trim()) t.sell = yn2(r[16]);
    n.targets++;
  });
  var BR = sheetBy(sheets, 'brands');
  if (BR) BR.slice(1).forEach(function (r) {
    var nm = String(r[0] || '').trim(); if (!nm) return;
    var yn = function (v) { v = String(v || '').trim().toLowerCase(); return v === '' ? null : /^(y|yes|true|1|on)/.test(v); };
    S.brands = S.brands || {}; delete S.brands[nm];
    var b2b = yn(r[1]), b2c = yn(r[2]), same = yn(r[7]);
    if (b2b === false) setBrand(nm, 'b2b', false); if (b2c === false) setBrand(nm, 'b2c', false); if (same) setBrand(nm, 'same', true);
    [[3, 'mB2b'], [4, 'fB2b'], [5, 'mB2c'], [6, 'fB2c'], [8, 'extra'], [9, 'duty'], [10, 'log']].forEach(function (f) { var v = numOrNull(r[f[0]]); if (v != null) setBrand(nm, f[1], v); });
    n.brands = (n.brands || 0) + 1;
  });
  var SH = sheetBy(sheets, 'shipping');
  if (SH) SH.slice(1).forEach(function (r) {
    var code = String(r[0] || '').trim().toUpperCase(); if (!code && !r[1]) return;
    var key = resolveSource(r[1]), v = numOrNull(r[2]);
    if (!S.targets[code] || !key) { bad.push('Shipping: ' + code + ' / ' + r[1]); return; }
    if (v != null) { S.targets[code].ship[key] = v; n.ship++; }
  });
  var SR = sheetBy(sheets, 'sources');
  if (SR) SR.slice(1).forEach(function (r) {
    var key = resolveSource(r[0]); if (!key) { if (String(r[0] || '').trim()) bad.push('Sources: ' + r[0]); return; }
    var keep = S.srcOpts[key]; delete S.srcOpts[key]; var base = srcCfg(key); // only save what differs from the built-in setting
    if (keep) S.srcOpts[key] = keep;
    var vat = numOrNull(r[1]); if (vat != null) setSrcOpt(key, 'vat', vat === base.vat ? '' : vat);
    var pm = String(r[2] || '').toLowerCase(); if (pm) { var md = /extra|checkout|added|excl/.test(pm) ? 'extra' : 'included'; setSrcOpt(key, 'mode', md === base.mode ? '' : md); }
    var rf = String(r[3] || '').trim().toLowerCase(); setSrcOpt(key, 'refund', rf === 'yes' || rf === 'y' ? 'yes' : rf === 'no' || rf === 'n' ? 'no' : '');
    n.src++;
  });
  var FX = sheetBy(sheets, 'rates');
  if (FX) FX.slice(1).forEach(function (r) {
    var c = String(r[0] || '').trim().toUpperCase(), v = numOrNull(r[1]); if (!/^[A-Z]{3}$/.test(c) || v == null) return;
    if (Math.abs((S.settings.fx[c] || 0) - v) > 1e-9) { S.settings.fx[c] = v; (S.settings.fxManual = S.settings.fxManual || {})[c] = true; n.fx++; }
  });
  return { n: n, bad: bad, found: !!(T || SH || SR || FX || BR) };
}
async function costingFromFile(file) {
  try {
    var sheets = await XLSX_READ.read(await file.arrayBuffer()), r = importCosting(sheets);
    if (!r.found) { banner('That Excel has no Targets, Shipping, Sources or Rates sheet. Press Costing template (Excel) to get the right layout.'); return; }
    ensureTargets(); renderSlab(); renderSettings(); renderShip(); renderResults(); save();
    banner('Imported: ' + r.n.targets + ' target countries, ' + r.n.ship + ' shipping values, ' + r.n.src + ' source VAT settings, ' + r.n.fx + ' exchange rates, ' + (r.n.brands || 0) + ' brands.' + (r.bad.length ? ' Not recognised (skipped): ' + r.bad.slice(0, 6).join('; ') + (r.bad.length > 6 ? '…' : '') : ''));
  } catch (e) { banner('Could not read that file. Save it as .xlsx (Excel workbook) and try again. (' + e.message + ')'); }
}
function exportJson() {
  var feed = visibleRows().map(function (r) {
    var c = r.calc || {};
    return { product: r.product, slug: r.slug, country: r.country, country_code: r.cc, status: r.status, in_stock: r.status === 'IN_STOCK', price_local: r.price, currency: r.cur,
      delivery: r.delivery, landed_usd: c.landed == null ? null : c.landed, sell_usd: c.sell == null ? null : c.sell, sell_b2b_usd: pubPrices(r).b2b, sell_b2c_usd: pubPrices(r).b2c, checked_at: new Date(r.checkedAt).toISOString(), url: r.url };
  });
  download('meta-stock-feed-' + stamp() + '.json', 'application/json', JSON.stringify({ generated_at: new Date().toISOString(), items: feed }, null, 2));
}

/* ---------- WordPress push ---------- */
var PUSHABLE = ['IN_STOCK', 'OUT_OF_STOCK', 'NOT_SOLD', 'NOTIFY', 'PREORDER', 'COMING_SOON'];
function wpOrigin() { try { return new URL((S.settings.wpUrl || '').trim()).origin; } catch (e) { return ''; } }
async function ensurePerm(origin) {
  var p = { origins: [origin + '/*'] };
  try { if (await chrome.permissions.contains(p)) return true; return await chrome.permissions.request(p); } catch (e) { return false; }
}
function wpStatus(msg) { S.settings.wpLast = msg; $('#wStatus').textContent = msg; save(); if (typeof setupBox === 'function') setupBox(); }
async function wpCall(path, method, body) {
  var origin = wpOrigin(); if (!origin) throw new Error('Enter the site address first');
  if (!S.settings.wpKey) throw new Error('Paste the API key from WordPress > Meta Stock');
  var opts = { method: method, headers: { 'Content-Type': 'application/json', 'X-AIG-Key': S.settings.wpKey }, body: body ? JSON.stringify(body) : undefined };
  var r = await fetch(origin + '/wp-json/aig-stock/v1/' + path, opts);
  if (r.status === 404) r = await fetch(origin + '/?rest_route=/aig-stock/v1/' + path, opts); // sites without pretty permalinks
  var j = null; try { j = await r.json(); } catch (e) {}
  if (!r.ok) throw new Error((j && j.message) || ('HTTP ' + r.status));
  return j;
}
// Reads the API key from the WordPress admin page (you must be logged in to wp-admin in this Chrome).
async function autoKey() {
  var origin = wpOrigin(); if (!origin) { wpStatus('Enter the site address first.'); return false; }
  if (!(await ensurePerm(origin))) { wpStatus('Chrome permission for ' + origin + ' was not granted.'); return false; }
  try {
    var r = await fetch(origin + '/wp-admin/admin.php?page=aig-meta-stock', { credentials: 'include' });
    var h = await r.text();
    var m = h.match(/readonly[^>]*value="([A-Za-z0-9]{20,})"/);
    if (!m) { wpStatus('Could not read the key. Log in to ' + origin + '/wp-admin in this Chrome, then press Auto-fill key again.'); return false; }
    S.settings.wpKey = m[1]; $('#wKey').value = m[1]; save();
    return true;
  } catch (e) { wpStatus('Could not read the key: ' + e.message); return false; }
}
async function wpTest() {
  var origin = wpOrigin(); if (!origin) { wpStatus('Enter the site address first.'); return; }
  if (!(await ensurePerm(origin))) { wpStatus('Chrome permission for ' + origin + ' was not granted.'); return; }
  if (!S.settings.wpKey && !(await autoKey())) return;
  try { var j = await wpCall('ping', 'GET'); wpStatus('Connected to ' + (j.site || origin) + ' (plugin v' + j.version + ').'); }
  catch (e) { wpStatus('Could not connect: ' + e.message + '. Is the plugin installed and active, and is the key correct?'); }
}
async function wpPush(silent) {
  var origin = wpOrigin(); if (!origin) { wpStatus('Enter the site address first.'); return false; }
  if (!silent && !(await ensurePerm(origin))) { wpStatus('Chrome permission for ' + origin + ' was not granted.'); return false; }
  var items = Object.keys(S.results).map(function (k) { return S.results[k]; })  .filter(function (r) { return !r.site && PUSHABLE.indexOf(r.status) !== -1; }).map(function (r) {
    return Object.assign({ slug: r.slug, product: r.product, cc: r.cc, status: r.status, price: r.price, currency: r.cur, price_raw: r.priceRaw || '', delivery: r.delivery || '', url: r.url, checked_at: new Date(r.checkedAt).toISOString() }, sellFields(r));
  });
  if (!items.length) { wpStatus('Nothing to push yet: run a check first.'); return false; }
  try {
    var saved = 0, wc = 0;
    for (var i = 0; i < items.length; i += 200) { var j = await wpCall('push', 'POST', { items: items.slice(i, i + 200), sites: siteRules(), global: globalRule() }); saved += j.saved || 0; wc += j.woocommerce_updated || 0; }
    wpStatus('Pushed ' + saved + ' rows to WordPress at ' + new Date().toLocaleTimeString() + (wc ? ' (' + wc + ' WooCommerce stock statuses updated)' : '') + '.');
    return true;
  } catch (e) { wpStatus('Push failed: ' + e.message); return false; }
}

/* ---------- customer requests ("Check stock & price" button on the website) ---------- */
var serving = false, servedAt = {};
async function serveRequests() {
  var s = S.settings;
  if (serving || s.listen === false || !s.wpKey || !wpOrigin()) return;
  serving = true;
  try {
    var j = await wpCall('pending', 'GET');
    var items = (j.items || []).filter(function (it) { var k = it.slug + '|' + it.cc; if (servedAt[k] && Date.now() - servedAt[k] < 40000) return false; servedAt[k] = Date.now(); return true; });
    if (!items.length) return;
    wpStatus('Customer request: checking ' + items.length + ' item(s)…');
    var conc = Math.max(1, Number(S.settings.concurrency) || 5), runOne = async function (it) {
      var country = countryInfo(it.cc); if (!country) return;
      var known = allProducts().find(function (p) { return p[0] === it.slug; });
      var row = await checkOne({ cc: country.cc, name: country.name, cur: country.cur }, { slug: it.slug, name: known ? known[1] : it.slug });
      var prev = S.results[row.key]; if (prev && prev.status !== 'ERROR') row.prevStatus = prev.status;
      S.results[row.key] = row; renderResults(); save();
      if (PUSHABLE.indexOf(row.status) === -1) { wpStatus('Customer request for ' + it.slug + ' could not be read (' + (STATUS_LABEL[row.status] || row.status) + ').'); return; }
      await wpCall('push', 'POST', { sites: siteRules(), global: globalRule(), items: [Object.assign({ slug: row.slug, product: row.product, cc: row.cc, status: row.status, price: row.price, currency: row.cur, price_raw: row.priceRaw || '', delivery: row.delivery || '', url: row.url, checked_at: new Date(row.checkedAt).toISOString() }, sellFields(row))] });
      wpStatus('Answered customer request: ' + row.product + ' (' + row.cc + ') ' + (STATUS_LABEL[row.status] || row.status) + ' at ' + new Date().toLocaleTimeString());
    };
    for (var bi = 0; bi < items.length; bi += conc) await Promise.all(items.slice(bi, bi + conc).map(runOne));
    if (!running) await closeWindow();
  } catch (e) { /* site unreachable or key wrong: shown by Test connection */ }
  finally { serving = false; }
}
function startListening() {
  var fallback = function () { setInterval(serveRequests, 8000); };
  try { var w = new Worker('ticker.js'); w.onmessage = function () { serveRequests(); }; w.onerror = fallback; } catch (e) { fallback(); }
  serveRequests();
}

/* ---------- websites (manual) + backup ---------- */
var editingSite = null;
function parsePages(text, pattern) {
  var out = [];
  String(text || '').split(/\r?\n/).forEach(function (line) {
    line = line.trim(); if (!line) return;
    var name = '', url = line, i = line.indexOf('|');
    if (i !== -1) { name = line.slice(0, i).trim(); url = line.slice(i + 1).trim(); }
    var id = '';
    if (!/^https?:\/\//i.test(url)) { if (pattern && pattern.indexOf('{id}') !== -1 && url) { id = url; url = pattern.replace('{id}', encodeURIComponent(url)); } else return; }
    if (!name) { try { var u = new URL(url); name = u.hostname.replace(/^www\./, '') + (u.pathname.length > 1 ? u.pathname.slice(0, 40) : ''); } catch (e) { name = url; } }
    out.push({ name: name, url: url, id: id });
  });
  return out;
}
function openSiteForm(site) {
  editingSite = site ? site.id : null;
  $('#wsTitle').textContent = site ? 'Edit website' : 'Add website';
  $('#wsName').value = site ? site.name : ''; $('#wsRegion').value = site ? (site.region || 'Other') : 'Americas';
  $('#wsCc').value = site ? site.cc || '' : ''; $('#wsCur').value = site ? site.cur || '' : ''; $('#wsVat').value = site ? site.vat || '' : '';
  $('#wsPattern').value = site ? site.pattern || '' : ''; $('#wsSearch').value = site ? site.searchUrl || '' : ''; $('#wsMode').value = site ? site.vatMode || 'included' : 'included'; $('#wsRefund').value = site && site.refund != null ? (site.refund ? 'yes' : 'no') : '';
  $('#wsUrls').value = site ? site.urls.map(function (u) { return u.name + ' | ' + (u.id || u.url); }).join('\n') : '';
  $('#wsForm').hidden = false; $('#wsName').focus();
}
function saveSite(e) {
  e.preventDefault();
  var name = $('#wsName').value.trim(), pat = $('#wsPattern').value.trim(), urls = parsePages($('#wsUrls').value, pat);
  if (!name) { banner('Enter the website name.'); return; }
  var old = editingSite ? siteById(editingSite) : null;
  if (!urls.length && !(old && old.kind === 'amazon')) { banner('Add at least one product page link starting with https:// (or an ID, if you set a page address pattern).'); return; }
  var rf = $('#wsRefund').value, site = { id: editingSite || ('w' + Date.now().toString(36)), kind: old ? old.kind : undefined, searchUrl: $('#wsSearch').value.trim(), vatMode: $('#wsMode').value, refund: rf === '' ? null : rf === 'yes', name: name, region: $('#wsRegion').value, cc: $('#wsCc').value.trim().toUpperCase(), cur: $('#wsCur').value.trim().toUpperCase(), vat: Number($('#wsVat').value) || 0, pattern: pat, urls: urls };
  if (old) site.urls.forEach(function (u) { var o = old.urls.find(function (x) { return x.url === u.url; }); if (o) { if (o.q) u.q = o.q; if (o.title) u.title = o.title; if (o.uid) u.uid = o.uid; } });
  var i = S.sites.findIndex(function (x) { return x.id === site.id; });
  if (i === -1) { S.sites.push(site); S.selSites.push(site.id); } else S.sites[i] = site;
  if (site.cur && S.settings.fx[site.cur] == null) { S.settings.fx[site.cur] = 0; banner('Saved. Set the ' + site.cur + ' currency rate in Settings (it is 0 until you do).'); } else banner('Saved ' + name + '.');
  $('#wsForm').hidden = true; editingSite = null; renderSites(); renderSettings(); save();
}
function syncMsg(t) { var e = document.getElementById('syncState'); if (e) e.textContent = t; }
function backupFile() {
  var c = JSON.parse(JSON.stringify(S)); c.settings.wpKey = ''; c.settings.wpLast = '';
  download('meta-stock-backup-' + stamp() + '.json', 'application/json', JSON.stringify({ msc_backup: 1, saved: new Date().toISOString(), data: c }));
  banner('Saved everything to your Downloads folder: countries, duties, VAT, margins, brands, products, variants, websites, links, rates, settings and results. Keep this file. After installing again press Load everything. (The WordPress key is not inside: press Auto-fill key.)');
}
function restoreFile(file) {
  var rd = new FileReader();
  rd.onload = function () {
    try { var j = JSON.parse(rd.result); if (!j.msc_backup || !j.data) throw new Error('not a backup'); applyConfig(j.data, false); fullRender(); save(); banner('Backup restored.'); }
    catch (e) { banner('That file is not a Meta Stock Checker backup.'); }
  };
  rd.readAsText(file);
}
function fullRender() { renderCountries(); renderSites(); renderProducts(); renderSettings(); renderSlab(); renderResults(); }


/* ---------- live exchange rates ---------- */
function usedCurrencies() {
  var curs = {};
  allCountries().forEach(function (c) { curs[c[3]] = 1; });
  S.sites.forEach(function (x) { if (x.cur) curs[x.cur] = 1; });
  return Object.keys(curs).sort();
}
function renderFx() {
  var s = S.settings, man = s.fxManual || {};
  $('#fxGrid').innerHTML = usedCurrencies().map(function (k) {
    var tag = man[k] ? 'manual' : (S.fxLive && S.fxLive.cur && S.fxLive.cur[k] ? 'live' : 'placeholder');
    return '<label>' + k + ' <span class="src-badge">' + tag + '</span><input data-fx="' + k + '" type="number" step="0.0001" min="0" value="' + (s.fx[k] == null ? '' : s.fx[k]) + '"></label>';
  }).join('');
  $('#fxStamp').textContent = S.fxLive && S.fxLive.date ? 'Rates updated: ' + S.fxLive.date + ' (free daily rates, not bank rates). Type a number to set your own rate for a currency; "Use live for all" undoes that.' : 'Rates are placeholders until you press Update rates now.';
}
async function refreshRates(silent) {
  try {
    var r = await fetch('https://open.er-api.com/v6/latest/USD'); if (!r.ok) throw new Error('HTTP ' + r.status);
    var j = await r.json(); if (!j || !j.rates) throw new Error('no rates');
    var man = S.settings.fxManual = S.settings.fxManual || {}, cur = {}, n = 0;
    usedCurrencies().forEach(function (k) {
      if (k === 'USD') { S.settings.fx.USD = 1; return; }
      var u = Number(j.rates[k]); if (!u) return;
      cur[k] = 1; if (!man[k]) { S.settings.fx[k] = Math.round(1 / u * 1e6) / 1e6; n++; }
    });
    S.fxLive = { date: (j.time_last_update_utc || '').slice(5, 16) || new Date().toISOString().slice(0, 10), day: new Date().toISOString().slice(0, 10), cur: cur };
    renderFx(); renderResults(); save();
    if (!silent) banner('Exchange rates updated (' + n + ' currencies).');
    return true;
  } catch (e) { if (!silent) banner('Could not fetch live rates (' + e.message + '). Your saved rates are unchanged.'); return false; }
}

/* ---------- searching a site (Find listings) ---------- */
async function searchSite(site, q) {
  var url = String(site.searchUrl || '').replace('{q}', encodeURIComponent(q)), fn = site.kind === 'amazon' ? amazonSearchPage : genericSearchPage;
  return await withTab(url, async function (tabId) {
    await waitComplete(tabId, 30000);
    var best = [];
    for (var i = 0; i < 8; i++) { await sleep(1200); var r = await inject(tabId, fn); if (r && r.length >= best.length) best = r; if (best.length >= 3 && i > 1) break; }
    return best;
  });
}
function pickBest(list, title) {
  var best = null, bs = 0;
  (list || []).forEach(function (x) { var sc = M.titleMatch(title, x.title); if (sc > bs) { bs = sc; best = x; } });
  return bs >= 0.6 ? best : null;
}
async function refindListing(site, ref) {
  try { var list = await searchSite(site, ref.q); await closeWindow(); var b = pickBest(list, ref.title || ref.name); return b ? b.url : null; }
  catch (e) { return null; }
}
var flFound = [];
function renderFindSources() {
  var o = '<option value="meta">Meta.com (product list)</option><option value="amazon-all">All ticked Amazon sites</option>';
  S.sites.filter(function (x) { return x.searchUrl; }).forEach(function (x) { o += '<option value="' + esc(x.id) + '">' + esc(x.name) + '</option>'; });
  var cur = $('#flSource').value; $('#flSource').innerHTML = o; if (cur) $('#flSource').value = cur;
}
function renderFindResults() {
  $('#flResults').innerHTML = flFound.map(function (x, i) {
    return '<label class="flrow"><input type="checkbox" data-fl="' + i + '"' + (x.on ? ' checked' : '') + '><span class="ft">' + esc(x.title) + '<div class="fs">' + esc(x.srcName) + (x.id ? ' · ' + esc(x.id) : '') + '</div></span><span class="fp">' + esc(x.priceText || '') + '</span></label>';
  }).join('');
  $('#flAdd').hidden = !flFound.length;
}
async function findListings() {
  var q = $('#flQuery').value.trim(), src = $('#flSource').value; if (!q) { $('#flStatus').textContent = 'Type what to search for.'; return; }
  if (running) return; flFound = []; renderFindResults(); $('#flGo').disabled = true;
  try {
    if (src === 'meta') {
      $('#flStatus').textContent = 'Reading the meta.com product list…';
      var pick = ['ae', 'us', 'gb', 'ca', 'au', 'in', 'ie'].find(function (c) { return S.selCountries.indexOf(c.toUpperCase()) !== -1; }) || 'ae';
      var found = await withTab(M.buildUrl(pick, '').replace(/\/\/$/, '/'), async function (tabId) {
        await waitComplete(tabId, 30000); var b = {};
        for (var i = 0; i < 8; i++) { await sleep(1500); var r = await inject(tabId, discoverPage); if (r && Object.keys(r).length >= Object.keys(b).length) b = r; if (Object.keys(b).length >= 3 && i > 3) break; }
        return b;
      });
      var words = q.toLowerCase().split(/[^a-z0-9]+/).filter(Boolean);
      Object.keys(found || {}).forEach(function (sl) {
        if (/^(compare|faq|support|accessories|accessibility|prescription|bluetooth-glasses|help|shop|all|shop-all|privacy|learn|refurbished)$/.test(sl)) return;
        var hay = (sl + ' ' + found[sl]).toLowerCase();
        if (words.every(function (w) { return hay.indexOf(w) !== -1; })) flFound.push({ kind: 'meta', slug: sl, title: found[sl] || sl, srcName: 'Meta.com', on: true });
      });
    } else {
      var sites = src === 'amazon-all' ? S.sites.filter(function (x) { return x.kind === 'amazon' && S.selSites.indexOf(x.id) !== -1; }) : [siteById(src)].filter(Boolean);
      if (!sites.length) { $('#flStatus').textContent = 'Tick at least one Amazon site first.'; $('#flGo').disabled = false; return; }
      for (var k = 0; k < sites.length; k++) {
        $('#flStatus').textContent = 'Searching ' + sites[k].name + ' (' + (k + 1) + '/' + sites.length + ')…';
        var list = []; try { list = await searchSite(sites[k], q); } catch (e) {}
        var bst = pickBest(list, q);
        list.slice(0, sites.length > 1 ? 3 : 10).forEach(function (x) { flFound.push({ kind: 'site', siteId: sites[k].id, id: x.id, url: x.url, title: x.title, priceText: x.priceText, srcName: sites[k].name, on: x === bst && sites.length > 1 }); });
        renderFindResults();
      }
      await closeWindow();
    }
    $('#flStatus').textContent = flFound.length ? flFound.length + ' result(s). Tick the right ones and press Add ticked.' : 'Nothing found. Try fewer words, or open the search page yourself and paste the product link.';
  } catch (e) { $('#flStatus').textContent = 'Search failed: ' + e.message; }
  $('#flGo').disabled = false; renderFindResults();
}
function addFound() {
  var name = $('#flName').value.trim(), q = $('#flQuery').value.trim(), n = 0;
  flFound.filter(function (x) { return x.on; }).forEach(function (x) {
    if (x.kind === 'meta') {
      if (!allProducts().some(function (p) { return p[0] === x.slug; })) S.customProducts.push({ slug: x.slug, name: name || x.title, discovered: true });
      else if (name) S.nameOverride[x.slug] = name;
      if (S.selProducts.indexOf(x.slug) === -1) S.selProducts.push(x.slug); n++;
    } else {
      var st = siteById(x.siteId); if (!st) return;
      var key = x.id || x.url;
      if (st.urls.some(function (u) { return (u.id || u.url) === key; })) return;
      st.urls.push({ name: name || x.title, url: x.url, id: x.id || '', q: q, title: x.title }); if (S.selSites.indexOf(st.id) === -1) S.selSites.push(st.id); n++;
    }
  });
  flFound = []; renderFindResults(); renderProducts(); renderSites(); save();
  $('#flStatus').textContent = 'Added ' + n + ' listing(s). Press Check selected.';
}

/* ---------- tidy variant names ---------- */
function tidyModel(m) { return String(m || '').replace(/^Meta Ray-Ban (?=Meta Ray-Ban)/i, '').replace(/\s+/g, ' ').trim(); }
function cleanVariant(model, label) {
  var l = String(label || '').replace(/^frame and lens colou?r of\s*/i, '').replace(/\s*,?\s*(selected|currently selected)\s*$/i, '').trim();
  var m = /^frame colou?r:\s*(.+?),\s*lens colou?r:\s*(.+)$/i.exec(l); if (m) return m[1].trim() + ' / ' + m[2].trim();
  var toks = ['ray-ban', 'meta', 'oakley', 'audio', 'optics', 'display', 'and', 'neural', 'band', '(audio)'];
  String(model).split(/\s+/).forEach(function (w) { w = w.toLowerCase().replace(/^[,]+|[,]+$/g, ''); if (w) toks.push(w); });
  for (var guard = 0; guard < 30; guard++) {
    var mm = /^[\s,]*(\(gen \d\)|[^\s,]+)/i.exec(l); if (!mm) break;
    if (toks.indexOf(mm[1].toLowerCase()) === -1 && !/^\(gen \d\)$/i.test(mm[1])) break;
    l = l.slice(mm[0].length);
  }
  l = l.replace(/^[\s,]+/, '').replace(/,\s*(standard|large)\s*$/i, '').replace(/,\s*/g, ', ').trim();
  return l;
}

/* ---------- import everything from a shop-all link ---------- */
async function importFromLink() {
  if (running) return;
  var link = $('#imLink').value.trim();
  if (!/^https:\/\/www\.meta\.com\//i.test(link)) { $('#imStatus').textContent = 'Paste a meta.com link, for example https://www.meta.com/in/ai-glasses/shop-all/'; return; }
  var cc = M.pathCountry(link), st = function (m) { $('#imStatus').textContent = m; };
  $('#imGo').disabled = true; st('Opening the shop page and reading every product…');
  var added = 0, products = 0, failed = 0, notes = 0;
  try {
    var cards = await withTab(link, async function (tabId) { await waitComplete(tabId, 30000); await sleep(2000); return await inject(tabId, shopAllPage); });
    var slugs = Object.keys(cards || {});
    if (!slugs.length) { st('Could not read products from that page (it may not have loaded). Try again.'); $('#imGo').disabled = false; await closeWindow(); return; }
    var seenModel = {};
    for (var i = 0; i < slugs.length; i++) {
      var raw = cards[slugs[i]], model = tidyModel(raw.replace(/^(limited-time offer|new|sale)\s+/i, '').replace(/\s+\d+\s+colou?rs?\b.*$/i, '').replace(/\s+from\s.*$/i, '').trim());
      if (seenModel[model.toLowerCase()]) continue; seenModel[model.toLowerCase()] = 1; products++;
      st('Reading ' + (i + 1) + '/' + slugs.length + ': ' + model + '…');
      var r = null;
      try { r = await withTab(M.buildUrl(cc, slugs[i]), async function (tabId) { await waitComplete(tabId, 30000); await sleep(1800); return await inject(tabId, variantsFullPage); }); } catch (e) {}
      if (!r || !r.found || !Object.keys(r.found).length) { failed++; if (!allProducts().some(function (x) { return x[0] === slugs[i]; })) { S.customProducts.push({ slug: slugs[i], name: model, discovered: true, variantOf: slugs[i], model: model }); S.selProducts.push(slugs[i]); added++; } continue; }
      var note = (r.sizes || []).join(' · ');
      Object.keys(r.found).forEach(function (sl) {
        var lab = cleanVariant(model, r.found[sl]);
        var nm = model + (lab ? ' – ' + lab : '');
        var ex = S.customProducts.find(function (c) { return c.slug === sl; });
        if (ex) { ex.opts = note; ex.model = ex.model || model; return; }
        if (allProducts().some(function (x) { return x[0] === sl; })) return;
        S.customProducts.push({ slug: sl, name: nm, discovered: true, variantOf: slugs[i], model: model, opts: note, src: link });
        if (S.selProducts.indexOf(sl) === -1) S.selProducts.push(sl); added++; if (note) notes++;
      });
      renderProducts(); save();
    }
  } catch (e) { st('Import stopped: ' + e.message); }
  await closeWindow(); $('#imGo').disabled = false; renderProducts(); save();
  st('Done: ' + products + ' products read, ' + added + ' new product/variant rows added' + (failed ? ' (' + failed + ' product page(s) had no colour options; added as one row)' : '') + '. Sizes/fit are saved as a note on each row. Press Check selected to check them in your ticked countries.');
}

/* ---------- Amazon helpers ---------- */
function addAsin() {
  var name = $('#amzName').value.trim(), asin = $('#amzAsin').value.trim().toUpperCase().replace(/^.*\/dp\//, '').replace(/[^A-Z0-9].*$/, '');
  if (!name || !/^[A-Z0-9]{10}$/.test(asin)) { banner('Enter the product name and a 10-character ASIN.'); return; }
  var n = 0;
  S.sites.filter(function (x) { return x.kind === 'amazon' && S.selSites.indexOf(x.id) !== -1; }).forEach(function (st) {
    if (st.urls.some(function (u) { return u.id === asin; })) return;
    st.urls.push({ name: name, id: asin, url: st.pattern.replace('{id}', asin), q: name, title: name }); n++;
  });
  $('#amzAsin').value = ''; renderSites(); save();
  banner(n ? 'Added ' + name + ' (' + asin + ') to ' + n + ' Amazon site(s). Other countries may use a different ASIN: use Find listings > All ticked Amazon sites.' : 'Tick at least one Amazon site first (or that ASIN is already added).');
}

/* ---------- discover variants ---------- */
async function discoverVariants() {
  if (running) return;
  var base = S.selProducts.slice(); if (!base.length) { banner('Tick the products first.'); return; }
  var pick = ['ae', 'us', 'gb', 'ca', 'au', 'in', 'ie'].find(function (c) { return S.selCountries.indexOf(c.toUpperCase()) !== -1; }) || 'ae', added = 0, failed = 0;
  $('#btnVariants').disabled = true;
  for (var i = 0; i < base.length; i++) {
    var p = allProducts().find(function (x) { return x[0] === base[i]; }); if (!p) continue;
    banner('Reading variants ' + (i + 1) + '/' + base.length + ': ' + p[1] + '…');
    var res = null;
    try { res = await withTab(M.buildUrl(pick, p[0]), async function (tabId) { await waitComplete(tabId, 30000); await sleep(1800); return await inject(tabId, variantsFullPage); }); } catch (e) {}
    if (!res || !res.found) { failed++; continue; }
    Object.keys(res.found).forEach(function (sl) {
      if (allProducts().some(function (x) { return x[0] === sl; })) return;
      var lab = cleanVariant(p[1], res.found[sl]);
      var nm = p[1] + (lab ? ' – ' + lab : ' – ' + sl);
      S.customProducts.push({ slug: sl, name: nm, discovered: true, variantOf: p[0], model: p[1], opts: (res.sizes || []).join(' · ') });
      S.selProducts.push(sl); added++;
    });
  }
  await closeWindow(); $('#btnVariants').disabled = false; renderProducts(); save();
  banner('Variants: ' + added + ' new product(s) added (' + failed + ' page(s) could not be read). Each variant is its own row; untick any you do not sell.');
}

/* ---------- wiring ---------- */
function toggle(arr, v, on) { var i = arr.indexOf(v); if (on && i === -1) arr.push(v); if (!on && i !== -1) arr.splice(i, 1); }
function wire() {
  $('#countryList').addEventListener('change', function (e) {
    var t = e.target;
    if (t.dataset.cc) toggle(S.selCountries, t.dataset.cc, t.checked);
    else if (t.dataset.region) allCountries().filter(function (c) { return c[2] === t.dataset.region; }).forEach(function (c) { toggle(S.selCountries, c[0], t.checked); });
    else if (t.dataset.log) { var v = t.value.trim(); if (v === '') delete S.logistics[t.dataset.log]; else S.logistics[t.dataset.log] = Number(v); renderResults(); save(); return; }
    renderCountries(); save();
  });
  $('#cSearch').addEventListener('input', renderCountries);
  $('#pSearch').addEventListener('input', renderProducts);
  $('#wsRegion').innerHTML = REGIONS.map(function (r) { return '<option>' + r + '</option>'; }).join('');
  document.addEventListener('click', function (e) {
    var f = e.target.dataset && e.target.dataset.fold; if (!f) return;
    S.closed[f] = !S.closed[f]; renderCountries(); renderSites(); save();
  });
  $('#siteList').addEventListener('change', function (e) {
    var t = e.target;
    if (t.dataset.site) toggle(S.selSites, t.dataset.site, t.checked);
    else if (t.dataset.sregion) S.sites.filter(function (x) { return (x.region || 'Other') === t.dataset.sregion; }).forEach(function (x) { toggle(S.selSites, x.id, t.checked); });
    renderSites(); save();
  });
  $('#siteList').addEventListener('click', function (e) {
    var ed = e.target.dataset && e.target.dataset.sedit, del = e.target.dataset && e.target.dataset.sdel;
    if (ed) openSiteForm(S.sites.find(function (x) { return x.id === ed; }));
    if (del && confirm('Remove this website and its product pages?')) { S.sites = S.sites.filter(function (x) { return x.id !== del; }); toggle(S.selSites, del, false); renderSites(); save(); }
  });
  $('#amazonList').addEventListener('change', function (e) { var t = e.target; if (t.dataset.site) { toggle(S.selSites, t.dataset.site, t.checked); renderSites(); save(); } });
  $('#amazonList').addEventListener('click', function (e) { var ed = e.target.dataset && e.target.dataset.sedit; if (ed) openSiteForm(siteById(ed)); });
  document.querySelectorAll('[data-amz]').forEach(function (b) {
    b.addEventListener('click', function () {
      var p = b.dataset.amz, list = S.sites.filter(function (x) { return x.kind === 'amazon'; });
      list.forEach(function (x) { toggle(S.selSites, x.id, p === 'all' ? true : p === 'none' ? false : x.region === p); });
      renderSites(); save();
    });
  });
  $('#amzAdd').addEventListener('click', addAsin);
  $('#flGo').addEventListener('click', findListings);
  $('#flAdd').addEventListener('click', addFound);
  $('#flResults').addEventListener('change', function (e) { var i = e.target.dataset && e.target.dataset.fl; if (i != null) flFound[Number(i)].on = e.target.checked; });
  $('#btnVariants').addEventListener('click', discoverVariants);
  $('#pExpand').addEventListener('click', function () { S.closedB = {}; S.openP = {}; allProducts().forEach(function (p) { S.openP[groupOf(p)] = true; }); renderProducts(); save(); });
  $('#pClear').addEventListener('click', function () {
    if (running) return;
    if (!confirm('Remove ALL products from the list (built-in and imported) and their saved Meta results? Amazon and other-website listings are kept. You can import again afterwards.')) return;
    S.hiddenProducts = {}; D.products.forEach(function (p) { S.hiddenProducts[p[0]] = true; });
    var gone = {}; S.customProducts.forEach(function (c) { gone[c.slug] = 1; }); D.products.forEach(function (q) { gone[q[0]] = 1; });
    Object.keys(S.results).forEach(function (k) { var r = S.results[k]; if (!r.site && gone[r.slug]) delete S.results[k]; });
    S.customProducts = []; S.selProducts = []; S.nameOverride = {}; S.openP = {};
    renderProducts(); renderResults(); save(); banner('All products cleared. Paste a shop-all link under "Import everything from a meta.com page" to import again.');
  });
  $('#pRestore').addEventListener('click', function () { S.hiddenProducts = {}; D.products.forEach(function (p) { if (S.selProducts.indexOf(p[0]) === -1) S.selProducts.push(p[0]); }); renderProducts(); save(); });
  $('#pCollapse').addEventListener('click', function () { S.openP = {}; renderProducts(); save(); });
  $('#imGo').addEventListener('click', importFromLink);
  $('#wsNew').addEventListener('click', function () { openSiteForm(null); });
  $('#wsCancel').addEventListener('click', function () { $('#wsForm').hidden = true; editingSite = null; });
  $('#wsForm').addEventListener('submit', saveSite);
  $('#wsAll').addEventListener('click', function () { S.selSites = S.sites.map(function (x) { return x.id; }); renderSites(); save(); });
  $('#wsNone').addEventListener('click', function () { S.selSites = []; renderSites(); save(); });
  $('#btnBackup').addEventListener('click', backupFile);
  $('#btnSaveAll').addEventListener('click', backupFile);
  $('#btnLoadAll').addEventListener('click', function () { $('#fileRestore').click(); });
  $('#btnRestore').addEventListener('click', function () { $('#fileRestore').click(); });
  $('#fileRestore').addEventListener('change', function (e) { if (e.target.files[0]) restoreFile(e.target.files[0]); e.target.value = ''; });
  $('#btnSyncRestore').addEventListener('click', async function () { var c = await syncRead(); if (!c) { banner('Nothing saved in Chrome sync yet (sign in to Chrome sync, then change any setting).'); return; } applyConfig(c); fullRender(); save(); banner('Restored from Chrome sync.'); });
  $('#btnXlsx').addEventListener('click', exportXlsx);
  $('#btnExportList').addEventListener('click', exportList);
  $('#btnCostOut').addEventListener('click', exportCosting);
  $('#btnCostIn').addEventListener('click', function () { $('#fileCost').click(); });
  $('#fileCost').addEventListener('change', function (e) { if (e.target.files[0]) costingFromFile(e.target.files[0]); e.target.value = ''; });
  $('#pExport').addEventListener('click', exportList);
  document.querySelectorAll('[data-preset]').forEach(function (b) {
    b.addEventListener('click', function () {
      var p = b.dataset.preset, list = allCountries();
      if (p === 'all') S.selCountries = list.map(function (c) { return c[0]; });
      else if (p === 'none') S.selCountries = [];
      else if (p === 'confirmed') S.selCountries = list.filter(function (c) { return c[5] === 'confirmed' || S.listedByMeta[c[0]]; }).map(function (c) { return c[0]; });
      else S.selCountries = list.filter(function (c) { return c[2] === p; }).map(function (c) { return c[0]; });
      renderCountries(); save();
    });
  });
  $('#productList').addEventListener('change', function (e) {
    var bg = e.target.dataset.bgroup; if (bg != null) { allProducts().filter(function (p) { return brandOf(p[1]) === bg; }).forEach(function (p) { toggle(S.selProducts, p[0], e.target.checked); }); renderProducts(); save(); return; }
    var gn = e.target.dataset.pgroup; if (gn != null) { allProducts().filter(function (p) { return groupOf(p) === gn; }).forEach(function (p) { toggle(S.selProducts, p[0], e.target.checked); }); renderProducts(); save(); return; }
    if (e.target.dataset.slug) { toggle(S.selProducts, e.target.dataset.slug, e.target.checked); renderProducts(); save(); } });
  $('#productList').addEventListener('click', function (e) {
    var bf = e.target.dataset && e.target.dataset.bfold; if (bf != null) { S.closedB = S.closedB || {}; S.closedB[bf] = !S.closedB[bf]; renderProducts(); save(); return; }
    var pf = e.target.dataset && e.target.dataset.pfold; if (pf != null) { S.openP = S.openP || {}; S.openP[pf] = !S.openP[pf]; renderProducts(); save(); return; }
    var slug = e.target.dataset && e.target.dataset.del; if (!slug) return;
    S.customProducts = S.customProducts.filter(function (p) { return p.slug !== slug; }); toggle(S.selProducts, slug, false); renderProducts(); save();
  });
  document.querySelectorAll('[data-pp]').forEach(function (b) {
    b.addEventListener('click', function () { S.selProducts = b.dataset.pp === 'all' ? allProducts().map(function (p) { return p[0]; }) : []; renderProducts(); save(); });
  });
  $('#btnAddProduct').addEventListener('click', function () {
    var name = $('#pName').value.trim(), slug = $('#pSlug').value.trim().replace(/^\/+|\/+$/g, '').replace(/^.*\/ai-glasses\//, '').toLowerCase();
    if (!slug && !name) return;
    if (!slug) {
      // Name only: first look for words of the name in products already known/discovered, else guess the slug from the name.
      var words = name.toLowerCase().split(/[^a-z0-9]+/).filter(Boolean);
      var hits = allProducts().filter(function (p) { var hay = (p[0] + ' ' + p[1]).toLowerCase(); return words.every(function (w) { return hay.indexOf(w) !== -1; }); });
      if (hits.length) {
        hits.forEach(function (p) { if (S.selProducts.indexOf(p[0]) === -1) S.selProducts.push(p[0]); });
        $('#pName').value = ''; renderProducts(); save();
        banner('Found ' + hits.length + ' product(s) matching "' + name + '" and ticked them: ' + hits.map(function (p) { return p[1]; }).join(', '));
        return;
      }
      slug = words.join('-');
      banner('"' + name + '" is not in the list yet. Added with the guessed address ' + slug + '. If the check says Unclear/Error, press Discover products or paste the product link from meta.com.');
    }
    if (allProducts().some(function (p) { return p[0] === slug; })) { banner('That slug is already in the list.'); return; }
    S.customProducts.push({ slug: slug, name: name || slug }); S.selProducts.push(slug); $('#pName').value = ''; $('#pSlug').value = ''; renderProducts(); save();
  });
  $('#btnEditNames').addEventListener('click', function () {
    $('#pEditText').value = allProducts().map(function (p) { return p[1] + ' | ' + p[0]; }).join('\n'); $('#pEdit').hidden = false;
  });
  $('#pEditCancel').addEventListener('click', function () { $('#pEdit').hidden = true; });
  $('#pEdit').addEventListener('submit', function (e) {
    e.preventDefault(); var ren = 0, add = 0; S.nameOverride = S.nameOverride || {};
    $('#pEditText').value.split(/\r?\n/).forEach(function (line) {
      var i = line.lastIndexOf('|'); if (i === -1) return;
      var name = line.slice(0, i).trim(), slug = line.slice(i + 1).trim().replace(/^\/+|\/+$/g, '').replace(/^.*\/ai-glasses\//, '').toLowerCase();
      if (!name || !slug) return;
      var ex = allProducts().find(function (p) { return p[0] === slug; });
      if (ex) { if (ex[1] !== name) { S.nameOverride[slug] = name; var cp = S.customProducts.find(function (p) { return p.slug === slug; }); if (cp) cp.name = name; ren++; } }
      else { S.customProducts.push({ slug: slug, name: name }); S.selProducts.push(slug); add++; }
    });
    $('#pEdit').hidden = true; renderProducts(); renderResults(); save(); banner('Product names saved: ' + ren + ' renamed, ' + add + ' added.');
  });
  $('#btnAddCountry').addEventListener('click', function () {
    var cc = (prompt('Country code used in the Meta URL (2 letters, e.g. SA):') || '').trim().toUpperCase(); if (!/^[A-Z]{2}$/.test(cc)) return;
    if (countryInfo(cc)) { banner(cc + ' is already in the list.'); return; }
    var name = (prompt('Country name:') || '').trim(); if (!name) return;
    var cur = (prompt('Currency code (e.g. SAR):') || '').trim().toUpperCase(); if (!cur) return;
    var vat = Number(prompt('Local VAT % included in Meta prices (placeholder is fine):') || 0) || 0;
    S.customCountries.push({ cc: cc, name: name, cur: cur, vat: vat, region: 'Other' }); S.selCountries.push(cc);
    if (S.settings.fx[cur] == null) S.settings.fx[cur] = 0;
    renderCountries(); renderSettings(); save(); banner('Added ' + name + '. Set its currency rate in Settings (it is 0 until you do).');
  });
  $('#btnDiscover').addEventListener('click', function () { if (!running) discoverProducts(); });
  $('#btnRefreshCountries').addEventListener('click', function () { if (!running) refreshCountries(); });
  [['#sConc', 'concurrency'], ['#sCache', 'cacheHours'], ['#sTimeout', 'timeoutSec']].forEach(function (p) {
    $(p[0]).addEventListener('input', function () { S.settings[p[1]] = Number($(p[0]).value) || 0; renderResults(); save(); });
  });
  $('#sIncl').addEventListener('change', function () { S.settings.includesVat = $('#sIncl').checked; renderResults(); save(); });
  $('#tTarget').addEventListener('change', function () { S.settings.destCode = $('#tTarget').value; renderSlab(); renderResults(); save(); });
  [['#tDuty', 'duty'], ['#tVat', 'vat'], ['#tExtra', 'extra'], ['#tLog', 'log'], ['#tMargin', 'margin'], ['#tFixed', 'fixed']].forEach(function (p) {
    $(p[0]).addEventListener('input', function () { curTarget()[p[1]] = Number($(p[0]).value) || 0; if (p[1] === 'log') renderShip(); renderSell(); renderResults(); save(); });
  });
  $('#tHost').addEventListener('input', function () { curTarget().host = $('#tHost').value.trim().toLowerCase().replace(/^https?:\/\//, '').replace(/^www\./, '').replace(/\/.*$/, ''); save(); });
  $('#tType').addEventListener('change', function () { curTarget().type = $('#tType').value; save(); });
  $('#tCur').addEventListener('input', function () { curTarget().cur = $('#tCur').value.trim().toUpperCase(); renderResults(); save(); });
  $('#tRound').addEventListener('change', function () { curTarget().round = $('#tRound').checked; save(); });
  $('#tPush').addEventListener('change', function () { curTarget().push = $('#tPush').checked; save(); });
  $('#sellBody').addEventListener('input', function (e) { var d = e.target.dataset || {}; if (d.tr && d.f) { setTarget(d.tr, d.f, e.target.value); if (d.f === 'log' && d.tr === S.settings.destCode) renderShip(); renderResults(); save(); } });
  $('#sellBody').addEventListener('change', function (e) {
    var d = e.target.dataset || {};
    if (d.trc) { S.targets[d.trc][d.f] = e.target.checked; if (d.tr === undefined) { renderResults(); save(); } }
    else if (d.tr && d.f === 'type') { setTarget(d.tr, 'type', e.target.value); renderResults(); save(); }
  });
  $('#sellBody').addEventListener('click', function (e) {
    var v = e.target.dataset && e.target.dataset.tview, x = e.target.dataset && e.target.dataset.tdel;
    if (v) { S.settings.destCode = v; renderSlab(); renderResults(); save(); }
    if (x && x !== 'GL') { S.targets[x].sell = false; S.targets[x].push = false; if (S.settings.destCode === x) S.settings.destCode = sellCodes()[0] || 'AE'; renderSlab(); renderResults(); save(); }
  });
  $('#sellAdd').addEventListener('click', function () {
    var code = (prompt('Country code (2 letters, e.g. IN):') || '').trim().toUpperCase(); if (!/^[A-Z]{2}$/.test(code) || code === 'GL') return;
    if (!S.targets[code]) {
      var name = (prompt('Country name:') || '').trim(); if (!name) return; var cur = curTarget();
      S.targets[code] = { name: name, duty: Number(prompt('Import duty % (placeholder is fine):') || 0) || 0, vat: Number(prompt('GST / VAT %:') || 0) || 0, extra: 0, margin: cur.margin, log: cur.log, fixed: 0, ship: {} };
    }
    var t = S.targets[code], ci = countryInfo(code); t.sell = true; t.push = true; if (!t.cur && ci && ci.cur) t.cur = ci.cur; if (!t.type) t.type = 'B2C';
    S.settings.destCode = code; renderSlab(); renderResults(); save();
  });
  [['#tMarginB2b', 'marginB2b'], ['#tFixedB2b', 'fixedB2b']].forEach(function (p) {
    $(p[0]).addEventListener('input', function () { var v = $(p[0]).value.trim(), t = curTarget(); if (v === '') delete t[p[1]]; else t[p[1]] = Number(v) || 0; renderBrands(); renderResults(); save(); });
  });
  $('#tSame').addEventListener('change', function () { curTarget().sameB2c = $('#tSame').checked; renderResults(); save(); });
  $('#sB2bOn').addEventListener('change', function () { S.settings.b2bOn = $('#sB2bOn').checked; renderResults(); save(); });
  $('#brandBody').addEventListener('input', function (e) { var d = e.target.dataset || {}; if (d.bf) { setBrand(d.brand, d.bf, e.target.value.trim() === '' ? '' : Number(e.target.value)); renderProducts(); renderResults(); save(); } });
  $('#brandBody').addEventListener('change', function (e) {
    var d = e.target.dataset || {};
    if (d.bc) { if (e.target.checked) setBrand(d.brand, d.bc, ''); else setBrand(d.brand, d.bc, false); renderProducts(); renderResults(); save(); }
    if (d.bs) { if (e.target.checked) setBrand(d.brand, 'same', true); else setBrand(d.brand, 'same', ''); renderResults(); save(); }
  });
  $('#tAdd').addEventListener('click', function () {
    var code = (prompt('Target country code (2 letters, e.g. NG):') || '').trim().toUpperCase(); if (!/^[A-Z]{2}$/.test(code)) return;
    if (S.targets[code]) { S.settings.destCode = code; renderSlab(); renderResults(); save(); return; }
    var name = (prompt('Country name:') || '').trim(); if (!name) return;
    var cur = curTarget();
    S.targets[code] = { name: name, duty: Number(prompt('Import duty % (placeholder is fine):') || 0) || 0, vat: Number(prompt('GST / VAT %:') || 0) || 0, extra: 0, margin: cur.margin, log: cur.log, fixed: 0, ship: {} };
    S.settings.destCode = code; renderSlab(); renderResults(); save();
  });
  $('#tShip').addEventListener('click', function () { var b = $('#shipBox'); b.hidden = !b.hidden; $('#tShip').textContent = b.hidden ? 'Shipping table ▾' : 'Shipping table ▴'; renderShip(); });
  $('#shipFilter').addEventListener('input', renderShip);
  $('#shipBody').addEventListener('input', function (e) { if (e.target.dataset.ship) { setShip(e.target.dataset.ship, e.target.value); renderResults(); save(); } });
  $('#shipBody').addEventListener('change', function (e) {
    var d = e.target.dataset || {}, key = d.svat || d.smode || d.srefund; if (!key) return;
    setSrcOpt(key, d.svat ? 'vat' : d.smode ? 'mode' : 'refund', e.target.value); renderShip(); renderResults(); save();
  });
  $('#shipBody').addEventListener('paste', function (e) {
    var el = e.target; if (!el.dataset || !el.dataset.ship) return;
    var txt = (e.clipboardData || window.clipboardData).getData('text'), vals = txt.split(/\r?\n/).map(function (x) { return x.split('\t').pop(); });
    if (vals.length > 1 && vals[vals.length - 1] === '') vals.pop();
    if (vals.length < 2) return;
    e.preventDefault();
    var inputs = Array.prototype.slice.call($('#shipBody').querySelectorAll('input.shipin')), i = inputs.indexOf(el);
    vals.forEach(function (v, k) { var inp = inputs[i + k]; if (inp) { inp.value = String(v).trim().replace(/[^0-9.\-]/g, ''); setShip(inp.dataset.ship, inp.value); } });
    renderResults(); save();
  });
  $('#fxGrid').addEventListener('input', function (e) { if (e.target.dataset.fx) { S.settings.fx[e.target.dataset.fx] = Number(e.target.value) || 0; (S.settings.fxManual = S.settings.fxManual || {})[e.target.dataset.fx] = true; renderResults(); save(); } });
  $('#fxGrid').addEventListener('change', renderFx);
  $('#fxUpdate').addEventListener('click', function () { refreshRates(false); });
  $('#fxAllLive').addEventListener('click', function () { S.settings.fxManual = {}; refreshRates(false); });
  [['#wUrl', 'wpUrl'], ['#wKey', 'wpKey']].forEach(function (p) { $(p[0]).addEventListener('input', function () { S.settings[p[1]] = $(p[0]).value.trim(); save(); }); });
  $('#wAuto').addEventListener('change', function () { S.settings.autoPush = $('#wAuto').checked; save(); });
  $('#wListen').addEventListener('change', function () { S.settings.listen = $('#wListen').checked; save(); });
  $('#wHours').addEventListener('input', function () { S.settings.autoHours = Math.max(0, Number($('#wHours').value) || 0); save(); });
  $('#btnWpTest').addEventListener('click', wpTest);
  $('#btnWpKey').addEventListener('click', async function () { if (await autoKey()) wpTest(); });
  $('#btnWpPush').addEventListener('click', function () { wpPush(false); });
  $('#btnCheck').addEventListener('click', function () { runChecks(false); });
  $('#btnForce').addEventListener('click', function () { runChecks(true); });
  $('#btnStop').addEventListener('click', function () { stopFlag = true; $('#btnStop').disabled = true; });
  ['#fStatus', '#fSource', '#fProduct', '#fBest', '#fLowest'].forEach(function (s) { $(s).addEventListener('change', renderResults); });
  $('#fText').addEventListener('input', renderResults);
  $('#fSort').addEventListener('change', function () { colSort.key = ''; renderResults(); });
  document.querySelectorAll('th.sortable').forEach(function (th) {
    th.addEventListener('click', function () { var k = th.dataset.sort; if (colSort.key === k) colSort.dir = -colSort.dir; else { colSort.key = k; colSort.dir = 1; } renderResults(); });
  });
  $('#btnCsv').addEventListener('click', exportCsv);
  $('#btnJson').addEventListener('click', exportJson);
  $('#btnClear').addEventListener('click', function () { if (confirm('Clear all saved results?')) { S.results = {}; renderResults(); save(); } });
}

function setupBox() {
  var el = $('#setupBox'); if (!el) return;
  var st = S.settings, w = st.wpLast || '';
  var conn = /^Connected|^Pushed/.test(w);
  var hasRes = Object.keys(S.results).length > 0;
  var steps = [
    [!!st.wpUrl, 'Website address set', 'Type your site address (https://aiglasses.ae) in the WordPress box'],
    [!!st.wpKey, 'WordPress key found', 'Log in to ' + (st.wpUrl || 'your site') + '/wp-admin in this same Chrome, then reload this page'],
    [conn, 'Connected to WordPress', 'Install and activate the plugin "AiGlasses Meta Stock" on WordPress, then reload this page'],
    [S.selProducts.length > 0 && S.selCountries.length > 0, 'Products and countries ticked', 'Tick the products and countries to watch (left side)'],
    [hasRes, 'First check done', 'Wait for the first automatic check, or press Manual > Check selected once'],
    [st.listen !== false, 'Answering customer clicks', 'Tick "Answer customer clicks" in the WordPress box'],
    [(Number(st.autoHours) || 0) > 0, 'Auto-check on', 'Set "Auto-check every" hours in the WordPress box']
  ];
  var bad = steps.filter(function (x) { return !x[0]; });
  el.className = 'setup ' + (bad.length ? 'bad' : 'ok');
  el.innerHTML = '<b>' + (bad.length ? 'Needs you: ' + bad[0][2] : 'Ready. Everything runs by itself. Keep Chrome open.') + '</b>' +
    steps.map(function (x) { return '<span class="' + (x[0] ? 'y' : 'n') + '">' + x[1] + '</span>'; }).join('');
}

/* ---------- autopilot: connect, re-check on a timer, push, answer customers - no buttons needed ---------- */
function autoState(msg) { var e = $('#apState'); if (e) e.textContent = msg; }
async function autopilot() {
  setupBox();
  try {
    if (S.settings.wpUrl && !S.settings.wpKey) await autoKey();
    if (S.settings.wpUrl && S.settings.wpKey) { await wpTest(); if (S.settings.autoPush && !/Could not/.test(S.settings.wpLast || '') && Object.keys(S.results).length && !running) await wpPush(true); }
  } catch (e) {}
  var tick = async function () {
    setupBox();
    var h = Number(S.settings.autoHours) || 0;
    if (!h) { autoState('Autopilot off (set "Auto-check every" hours)'); return; }
    if (!S.settings.lastAuto) { var lr = Object.keys(S.results).reduce(function (m, k) { return Math.max(m, S.results[k].checkedAt || 0); }, 0); S.settings.lastAuto = lr || Date.now(); save(); }
    var due = S.settings.lastAuto + h * 3600e3;
    if (running) { autoState('Autopilot: checking now…'); return; }
    if (Date.now() >= due) {
      if (!S.selProducts.length || !S.selCountries.length) { autoState('Autopilot waiting: tick products and countries once'); return; }
      S.settings.lastAuto = Date.now(); save();
      await runChecks(true);
      return;
    }
    autoState('Autopilot on · next check ' + new Date(due).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) + ' · pushes to WordPress by itself');
  };
  setInterval(tick, 30000); tick();
}

(async function init() {
  await load(); ensureTargets(); renderCountries(); renderSites(); renderProducts(); renderSettings(); renderSlab(); wire(); renderResults(); startListening(); autopilot();
  if (!S.fxLive || S.fxLive.day !== new Date().toISOString().slice(0, 10)) refreshRates(true);
  if (/[?&]auto=1/.test(location.search)) {
    await runChecks(false);
    if (S.settings.autoPush && S.settings.wpKey && S.settings.wpUrl && !running) await wpPush(true);
    setTimeout(function () { chrome.tabs.getCurrent(function (t) { if (t) chrome.tabs.remove(t.id); }); }, 1500);
  }
})();
