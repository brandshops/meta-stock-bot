// Tiny .xlsx reader (no libraries): returns {sheetName: [[cell,...],...]}. Works with Excel / Google Sheets / our own files.
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.XLSX_READ = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  var dec = new TextDecoder('utf-8');
  function u16(b, o) { return b[o] | (b[o + 1] << 8); }
  function u32(b, o) { return (b[o] | (b[o + 1] << 8) | (b[o + 2] << 16) | (b[o + 3] << 24)) >>> 0; }
  async function inflate(bytes) {
    var ds = new DecompressionStream('deflate-raw'), w = ds.writable.getWriter();
    w.write(bytes); w.close();
    return new Uint8Array(await new Response(ds.readable).arrayBuffer());
  }
  async function unzip(buf) {
    var b = new Uint8Array(buf), eo = -1, i;
    for (i = b.length - 22; i >= 0 && i > b.length - 70000; i--) if (u32(b, i) === 0x06054b50) { eo = i; break; }
    if (eo < 0) throw new Error('not a zip');
    var n = u16(b, eo + 10), p = u32(b, eo + 16), files = {};
    for (i = 0; i < n; i++) {
      var method = u16(b, p + 10), csize = u32(b, p + 20), nl = u16(b, p + 28), el = u16(b, p + 30), cl = u16(b, p + 32), lo = u32(b, p + 42);
      var name = dec.decode(b.subarray(p + 46, p + 46 + nl));
      var lnl = u16(b, lo + 26), lel = u16(b, lo + 28), start = lo + 30 + lnl + lel, raw = b.subarray(start, start + csize);
      files[name] = { method: method, raw: raw };
      p += 46 + nl + el + cl;
    }
    return files;
  }
  async function text(files, name) {
    var f = files[name]; if (!f) return null;
    var data = f.method === 0 ? f.raw : await inflate(f.raw);
    return dec.decode(data);
  }
  function unesc(s) { return String(s).replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&#(\d+);/g, function (m, d) { return String.fromCharCode(+d); }).replace(/&#x([0-9a-f]+);/gi, function (m, d) { return String.fromCharCode(parseInt(d, 16)); }).replace(/&amp;/g, '&'); }
  function tText(x) { var out = '', re = /<t[^>]*>([\s\S]*?)<\/t>/g, m; while ((m = re.exec(x))) out += unesc(m[1]); return out; }
  function colIdx(ref) { var l = /^[A-Z]+/.exec(ref)[0], n = 0; for (var i = 0; i < l.length; i++) n = n * 26 + (l.charCodeAt(i) - 64); return n - 1; }
  async function read(buf) {
    var files = await unzip(buf);
    var wb = await text(files, 'xl/workbook.xml'), rels = await text(files, 'xl/_rels/workbook.xml.rels'), sst = await text(files, 'xl/sharedStrings.xml');
    if (!wb) throw new Error('not an xlsx');
    var strings = []; if (sst) { var re = /<si[^>]*>([\s\S]*?)<\/si>/g, m; while ((m = re.exec(sst))) strings.push(tText(m[1])); }
    var relMap = {}; (rels || '').replace(/<Relationship\b[^>]*>/g, function (t) { var id = /Id="([^"]+)"/.exec(t), tg = /Target="([^"]+)"/.exec(t); if (id && tg) relMap[id[1]] = tg[1]; return ''; });
    var out = {}, sheets = [], sr = /<sheet\b[^>]*>/g, sm;
    while ((sm = sr.exec(wb))) { var nm = /name="([^"]*)"/.exec(sm[0]), rid = /r:id="([^"]+)"/.exec(sm[0]); if (nm && rid) sheets.push({ name: unesc(nm[1]), target: relMap[rid[1]] }); }
    for (var k = 0; k < sheets.length; k++) {
      var tg = sheets[k].target || ''; tg = tg.replace(/^\/?(xl\/)?/, ''); var xml = await text(files, 'xl/' + tg); if (xml == null) continue;
      var rows = [], rr = /<row\b[^>]*>([\s\S]*?)<\/row>/g, rm;
      while ((rm = rr.exec(xml))) {
        var row = [], cr = /<c\b([^>]*?)(?:\/>|>([\s\S]*?)<\/c>)/g, cm;
        while ((cm = cr.exec(rm[1]))) {
          var at = cm[1], inner = cm[2] || '', ref = /r="([A-Z]+\d+)"/.exec(at), ty = /t="([^"]+)"/.exec(at), v = /<v>([\s\S]*?)<\/v>/.exec(inner), val = '';
          if (ty && ty[1] === 'inlineStr') val = tText(inner);
          else if (ty && ty[1] === 's') val = v ? strings[+v[1]] || '' : '';
          else if (v) { val = unesc(v[1]); if (!ty || ty[1] === 'n') { var num = Number(val); if (val !== '' && isFinite(num)) val = num; } }
          var ci = ref ? colIdx(ref[1]) : row.length; while (row.length < ci) row.push(''); row[ci] = val;
        }
        rows.push(row);
      }
      out[sheets[k].name] = rows;
    }
    return out;
  }
  return { read: read };
});
