# A Subh Meta Stock Checker (v1.6.6)

Checks live stock, price and delivery of Meta AI glasses on every meta.com country store, then works out landed cost and selling price.

## Install (2 minutes)
1. Unzip the folder.
2. Chrome > address bar: `chrome://extensions` > turn on **Developer mode** (top right).
3. Click **Load unpacked** > choose the `meta-stock-checker` folder.
4. Click the extension icon in the toolbar. The dashboard opens.

## Use
1. Tick countries (presets: All, Confirmed only, Europe, Americas, Asia-Pacific, Middle East). Press **Refresh from Meta** to read Meta's own supported-country list.
2. Tick products. Press **Discover products** to pull the current range from meta.com.
3. Press **Check selected**. Results saved in the last few hours are skipped; **Force re-check** ignores them.
4. Table shows status, local price, delivery, then net cost, logistics, duty, VAT, landed cost and selling price in USD.
5. **CSV** or **JSON feed** to export (the JSON feed is for your WordPress site).

## Things to know
- Meta shows each country store by where YOU are browsing from. Some stores (for example the US when browsing from India) redirect to your own country. Those rows show **Redirected**. To check them, use a computer or VPN located in that country.
- If Meta shows a login or security page, the run pauses. Open meta.com normally, complete it, then press Check selected again.
- Duty, VAT, currency rates and logistics costs are PLACEHOLDERS. Edit them in Settings and per country ("log $").
- Price is the number shown on the page. Out-of-stock pages show no price.

## WordPress (aiglasses.ae)
1. Install the `aig-meta-stock.zip` plugin on the site (WordPress admin > Plugins > Add New > Upload Plugin > Activate).
2. In WordPress open **Meta Stock** in the left menu and copy the API key.
3. In the extension, "WordPress" box: paste the key, press **Test connection** (Chrome asks permission for your site, press Allow), then **Push to WordPress**.
4. Tick "Push automatically after every check run". Set "Auto-check every (hours)" to run on a schedule while Chrome is open.
5. On a product page add the shortcode `[aig_meta_stock]` and, in the product's side box "Meta store stock link", enter the Meta slug (for example `ray-ban-meta-gen-2`).

## Customer "Check stock & price" button (v1.5)
- The plugin shows a button on every product page that has a Meta slug. When a customer clicks it, the page says "Checking Local & Global Stock…".
- The request goes to WordPress, and this extension (Chrome open on your computer, "Answer customer clicks" ticked) checks the Meta page and sends the answer back, usually within 10-30 seconds.
- If Chrome is closed or Meta cannot be read, the customer sees the Pre-book message after 60 seconds. Nothing is promised that was not confirmed.
- The answer is for the default colour shown on Meta's page for that model.

## v1.3 additions
- **Meta.com block**: countries as cards, grouped by continent (tick a whole continent, fold/unfold).
- **Other websites block**: press **+ Add website**, enter name, continent, country, currency, VAT %, and the product page links (one per line, `Name | link`). Saved automatically; tick/untick like countries. These rows are for your own comparison and are not pushed to WordPress.
- **Excel** button downloads a real .xlsx (Results + Assumptions sheets). CSV and JSON feed remain.
- **Save & restore**: lists, websites, costs and settings are copied to Chrome sync automatically and restored on a fresh install (sign in to Chrome sync). Also **Backup to file** / **Restore from file**. The WordPress key is not saved: press Auto-fill key.

## v1.4: costing bar and compact lists
- **Costing bar (top)**: pick the **target country** (where your customer is) and fill import duty %, GST/VAT %, extra expenses $/unit, default shipping $/unit and profit margin %. Values are saved per target country. The table shows net, shipping, duty, VAT, extra, landed, sell price and profit.
- **Shipping table**: press "Shipping table" to type the shipping $ from each source (meta.com/xx or website) to the selected target country. Blank uses the default. You can copy a column from Excel and paste it into the first cell.
- **meta.com** and **Other websites** are now compact tick boxes (meta.com/in, meta.com/us, ...). Use the same product name on different websites to compare them side by side; the summary shows the cheapest in-stock source per product name.

## v1.5
- Fixed "Unclear" on stores that use other wording for the buy button (German "In die Einkaufstasche", Dutch "Toevoegen aan tas", Spanish "Añadir a la bolsa", Swedish, Danish, Japanese, Korean, Polish, Finnish, Norwegian and more). Unclear rows now show the buttons they saw (hover the row).
- Sort by price low to high / high to low / landed cost / available first. Filters: available, not available, source, product, "Best listing only".
- Costing bar has an **Extra fixed profit $** box and a one-line summary; "How is the price calculated?" shows a worked example from your own first result.
- **Edit names / add many**: rename products or paste many `Name | address` lines at once.
- Other websites: optional **page address pattern** (for example `https://www.amazon.ae/dp/{id}`) so you only enter the stable ID per listing.

## v1.6
- **VAT per website / country**: Sources: shipping & VAT table now has VAT %, "Price shown" (includes VAT, or tax added at checkout) and "VAT refund" (Default / Yes / No) for every Meta country, Amazon site and other website. If the site adds tax at checkout it is added, and if you cannot get VAT back it is never removed from your cost.
- **Amazon worldwide**: 23 Amazon sites with continent buttons. Add Name + ASIN once and it is added to every ticked Amazon site. Amazon rows stay in the extension and Excel (they are not pushed to WordPress).
- **Find listings**: search Meta.com, all ticked Amazon sites, or any website that has a search link ({q}); tick the right results and they are saved under one product name. If a saved page later disappears, the check searches again by title and refreshes the link.
- **Lowest price only** filter: one row per product name, the in-stock source with the lowest sell price in USD for the target country.
- **Live exchange rates**: updated daily (free open.er-api.com), shows the update date, type your own number to override one currency, "Use live for all" to undo.
- **Discover variants**: opens each ticked product page and clicks every frame/lens colour, adding each as its own product row.

## v1.6.1
- Every result row shows the country and, under it, the website (Meta.com, or Amazon · amazon.ae etc.).
- Click any column heading (Product, Country, Status, Price, Net, Shipping, Duty, VAT, Extra, Landed, Sell, Profit, Checked) to sort; click again to reverse. Arrow icon shows direction; empty values stay at the bottom.

## v1.6.2
- Import from a shop-all link (Products card): paste e.g. https://www.meta.com/in/ai-glasses/shop-all/ and press Import. Opens every product, adds each frame/lens colour as its own product row named "Model – colour/lens", and saves sizes/fit as a note (ⓘ sizes). Run again any time new glasses launch: only new rows are added.

## v1.6.3
- Products are grouped by model (parent). Click the arrow on a group to open/close it, or use Expand all / Collapse all. The group checkbox ticks or unticks all its variants (partly ticked shows a dash). Searching opens the matching groups.

## v1.6.4
- Clear all products button (Products card): empties the product list and its saved Meta results so you can import again. Amazon / other-website listings are kept. Restore built-in list brings the original products back.

## v1.6.5
- Import finds every colour on pages that redraw after each click (Oakley HSTN, Gen 1 Wayfarer/Skyler, Display).
- Variant names are tidied: "Model – frame, lens" without repeated model words or stray commas; Oakley shows "Black / Clear".
- Export products + websites (Excel): sheets Products (with sizes note, ticked, renamed + original name, import link, type), Websites, Website listings, Meta countries. Uses your current names and settings.

## v1.6.6
- New defaults: shipping $3, margin 15%, extra $0, UAE import duty 0% and VAT 5%. Old placeholder values (25 / 20% / UAE 5%) are moved to these once; anything you set yourself is kept.
- Costing in Excel: "Costing template (Excel)" downloads sheets Targets, Shipping, Sources, Rates with your current numbers; edit and press "Import costing (Excel)". Blank cells keep current values; new target codes add countries.

## v1.7.0 – brands, B2B and B2C prices
- Products are now grouped Brand > Model > Variant. Tick a brand to tick all its products; fold a brand with its arrow.
- Costing > **Brands** table: per brand switch B2B and/or B2C on or off, and give it its own margin, fixed profit, extra, duty and shipping. Blank = use the target-country number.
- Two sell prices from one landed cost: B2C (margin % + fixed) and B2B (own margin % + fixed; blank = same as B2C). "B2C = B2B" makes both the same.
- Results table has Sell B2C / Profit B2C / Sell B2B / Profit B2B. Exports include both. The Excel costing template has a Brands sheet and B2B columns on Targets.
- Master switch "B2B prices switched on": off = B2B price is not calculated for the website and not sent to WordPress.
- Push to WordPress now also sends sell_b2c, sell_b2b and sell_cur (price in the target country's currency).
- WordPress plugin 1.2.0: Settings > "Price shown" (Meta price or our selling price). B2B price appears only on websites listed under "B2B price" (default eyeboss.in); every other website shows the B2C price. Untick the B2B box to switch B2B off everywhere, or remove a website from the list to switch it off for that store only. A brand with that price off shows no price.

## v1.8.0 – one price rule per website
- Costing bar, per country: Website (e.g. eyeboss.in), Website shows B2C or B2B, Price currency, Round to whole number, and "Send this country's prices to WordPress". Fill once per country; it is saved.
- Push to WordPress sends the final price for every ticked country in its own currency, plus the website rules. The plugin then shows each website its own country, currency and price type.
- Plugin 1.3.0: Meta Stock page has a "Link website products to Meta products" table with an Auto-link by name button.

## v1.9.0 – selling countries (one row each) + Global
- Costing now has one row per selling country: website(s), B2C/B2B, currency, duty, VAT, extra, shipping, B2C and B2B margin/fixed, round, send. "+ Add country" adds a row; "view" shows that country in the detailed columns below.
- A fixed **Global** row is the price for every website not listed in a country row.
- Results table, CSV and Excel have "Final <country> B2C / B2B" columns in each country's own currency. The Targets sheet of the costing template has the new columns.
- Plugin 1.4.0: a listed domain shows its own country's price; any other domain shows the Global price.

## v1.9.1
- Top of the page: **Save everything** (one file with all countries, duties, VAT, margins, brands, products, variants, websites, links, rates, settings and results) and **Load everything** (after installing again).
- Save & restore card shows when the Chrome sync copy was last saved, or warns if it is too big.

## v1.9.2
- Website checks from customers are answered in batches (your Concurrency setting) so a worldwide search does not open every page at once.
- Plugin 1.5.0: if the visitor's local store has no stock, the "Check stock & price" button searches every country and shows the lowest price in stock (setting: Search the whole world).

## v1.9.3
- Fixed: many background Chrome windows opened at once. All checks now share one work window, which is closed after use (and after 8 seconds of being idle).

## v2.0.0 – Autopilot
Connects to WordPress by itself, re-checks every 3 hours (default), pushes after every run, answers customer clicks. Manual buttons are folded under "Manual".

## v2.0.1
WordPress sites (aiglasses.ae, eyeboss.in) pre-approved, so no permission prompt. On every open it reads the key, tests, and pushes saved results by itself.

## v2.0.2
Setup box on top: red with the one thing you must do, green when ready.
