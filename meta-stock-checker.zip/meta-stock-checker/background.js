// Toolbar icon opens (or focuses) the dashboard; an optional alarm opens it in the background to run auto-checks.
const DASH = chrome.runtime.getURL('dashboard.html');

chrome.action.onClicked.addListener(async () => {
  const tabs = await chrome.tabs.query({ url: DASH + '*' });
  if (tabs.length) {
    await chrome.tabs.update(tabs[0].id, { active: true });
    await chrome.windows.update(tabs[0].windowId, { focused: true });
  } else {
    await chrome.tabs.create({ url: DASH });
  }
});

async function schedule() {
  const g = await chrome.storage.local.get('msc');
  const h = Number(g.msc && g.msc.settings && g.msc.settings.autoHours) || 0;
  await chrome.alarms.clear('msc-auto');
  if (h > 0) chrome.alarms.create('msc-auto', { periodInMinutes: h * 60, delayInMinutes: 1 });
}
async function listenAlarm() { chrome.alarms.create('msc-listen', { periodInMinutes: 0.5, delayInMinutes: 0.5 }); }
chrome.runtime.onInstalled.addListener(listenAlarm);
chrome.runtime.onStartup.addListener(listenAlarm);
listenAlarm();
chrome.runtime.onInstalled.addListener(schedule);
chrome.runtime.onStartup.addListener(schedule);
chrome.storage.onChanged.addListener((c) => {
  if (!c.msc) return;
  const o = (c.msc.oldValue && c.msc.oldValue.settings && c.msc.oldValue.settings.autoHours) || 0;
  const n = (c.msc.newValue && c.msc.newValue.settings && c.msc.newValue.settings.autoHours) || 0;
  if (o !== n) schedule();
});
chrome.alarms.onAlarm.addListener(async (a) => {
  if (a.name === 'msc-listen') {
    try {
      const g = await chrome.storage.local.get('msc');
      const s = (g.msc && g.msc.settings) || {};
      if (s.listen === false || !s.wpKey || !s.wpUrl) return;
      const open = await chrome.tabs.query({ url: DASH + '*' });
      if (open.length) return; // the open dashboard answers requests itself
      const r = await fetch(new URL(s.wpUrl).origin + '/wp-json/aig-stock/v1/pending?peek=1', { headers: { 'X-AIG-Key': s.wpKey } });
      const j = await r.json();
      if (j.items && j.items.length) await chrome.tabs.create({ url: DASH + '?listen=1', active: false });
    } catch (e) {}
    return;
  }
  if (a.name !== 'msc-auto') return;
  const tabs = await chrome.tabs.query({ url: DASH + '*' });
  if (tabs.length) return; // dashboard already open: do not start a second run
  await chrome.tabs.create({ url: DASH + '?auto=1', active: false });
});
