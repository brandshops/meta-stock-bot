// Runs in a Web Worker so the 5-second tick is not slowed down when the dashboard tab is in the background.
setInterval(function () { postMessage(1); }, 5000);
