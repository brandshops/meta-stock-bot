// Pure logic: status classification, price/delivery parsing, landed-cost maths. No browser APIs, so it is unit-tested in Node.
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.MSC = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  var KW = {
    notSold: ['not sold in your region', 'not available in your region', 'not available in your country',
      'nicht in ihrer region', 'in ihrer region nicht', 'non vendu dans votre région', 'non disponible dans votre région',
      'non disponibile nella tua regione', 'no se vende en tu región', 'niet verkocht in jouw regio',
      'não disponível na sua região', 'ikke solgt i din region', 'inte tillgänglig i din region'],
    // Buy button wording seen on the real meta.com stores (Oct 2026) plus likely variants.
    buy: ['add to cart', 'add to bag', 'buy now', 'in den warenkorb', 'in die einkaufstasche', 'in den einkaufskorb', 'jetzt kaufen', 'ajouter au panier', 'ajouter au sac',
      'aggiungi al carrello', 'aggiungi alla borsa', 'acquista ora', 'añadir a la bolsa', 'añadir a la cesta', 'añadir al carrito', 'agregar al carrito', 'agregar a la bolsa', 'comprar ahora',
      'in winkelwagen', 'toevoegen aan tas', 'toevoegen aan winkelwagen', 'nu kopen', 'adicionar à sacola', 'adicionar à bolsa', 'adicionar ao carrinho', 'adicionar a sacola',
      'læg i kurv', 'føj til kurv', 'føj til taske', 'legg i handlekurv', 'legg i handlepose', 'lägg i varukorg', 'lägg till i kassen', 'lägg i kassen', 'lisää ostoskoriin', 'lisää ostoskassiin',
      'dodaj do torby', 'dodaj do koszyka', 'バッグに追加', 'カートに追加', '장바구니에 담기', '加入購物袋', '加入購物車', '加入购物袋', '加入购物车'],
    preorder: ['pre-order', 'preorder', 'vorbestellen', 'précommander', 'preordina', 'pre-bestellen', 'pré-encomendar'],
    notify: ['notify me', 'email me when', 'get notified', 'benachrichtigen', 'prévenez-moi', 'avvisami', 'avísame'],
    out: ['sold out', 'out of stock', 'currently unavailable', 'unavailable', 'ausverkauft', 'nicht verfügbar', 'nicht auf lager', 'nicht vorrätig', 'rupture de stock', 'sin existencias',
      'niet op voorraad', 'não disponível', 'nao disponivel', 'sem estoque', 'ikke på lager', 'ikke tilgjengelig', 'ei varastossa', 'wyprzedane', 'brak w magazynie', '在庫切れ', '売り切れ', '品切れ', '품절', '缺貨', '已售罄',
      'épuisé', 'indisponible', 'esaurito', 'non disponibile', 'agotado', 'no disponible', 'uitverkocht',
      'niet beschikbaar', 'esgotado', 'indisponível', 'udsolgt', 'utsolgt', 'slutsåld', 'loppuunmyyty'],
    soon: ['coming soon', 'bald verfügbar', 'bientôt disponible', 'prossimamente', 'próximamente', 'binnenkort', 'em breve']
  };

  function norm(s) { return (s || '').toLowerCase().replace(/\s+/g, ' ').trim(); }
  function hasAny(t, list) { for (var i = 0; i < list.length; i++) if (t.indexOf(list[i]) !== -1) return true; return false; }

  // buttons: [{text, disabled}], text: visible page text
  function classify(buttons, text) {
    buttons = buttons || [];
    var t = norm(text);
    if (hasAny(t, KW.notSold)) return 'NOT_SOLD';
    var enabled = buttons.filter(function (b) { return !b.disabled; });
    var disabled = buttons.filter(function (b) { return b.disabled; });
    if (enabled.some(function (b) { return hasAny(norm(b.text), KW.buy); })) return 'IN_STOCK';
    if (enabled.some(function (b) { return hasAny(norm(b.text), KW.preorder); })) return 'PREORDER';
    if (buttons.some(function (b) { return hasAny(norm(b.text), KW.notify); })) return 'NOTIFY';
    // Some pages render the buy control as a plain element, not a button: accept a line that is exactly a buy phrase.
    var lines = String(text || '').split(/[\n\r]+/).map(norm).filter(Boolean);
    var lineIs = function (list) { return lines.some(function (l) { return list.indexOf(l) !== -1; }); };
    if (lineIs(KW.buy) && !lineIs(KW.out)) return 'IN_STOCK';
    if (hasAny(t, KW.out) || disabled.some(function (b) { return hasAny(norm(b.text), KW.buy); })) return 'OUT_OF_STOCK';
    if (hasAny(t, KW.soon)) return 'COMING_SOON';
    return 'UNKNOWN';
  }

  // "1,299.00" "1.299,00" "329,99" "1.299" "29,990" "24 990"
  function parseNumber(tok) {
    var s = String(tok).replace(/[\s  ]/g, '');
    var lc = s.lastIndexOf(','), ld = s.lastIndexOf('.');
    if (lc !== -1 && ld !== -1) {
      if (lc > ld) s = s.replace(/\./g, '').replace(',', '.');
      else s = s.replace(/,/g, '');
    } else if (lc !== -1) {
      s = /,\d{3}$/.test(s) && s.split(',').length >= 2 && s.length > 4 ? s.replace(/,/g, '') : s.replace(',', '.');
    } else if (ld !== -1) {
      if (/\.\d{3}$/.test(s) && s.length > 4) s = s.replace(/\./g, '');
    }
    var v = parseFloat(s);
    return isNaN(v) ? null : v;
  }

  var NUM = '\\d{1,3}(?:[.,\\s\\u00a0\\u202f]\\d{3})+(?:[.,]\\d{1,2})?|\\d+(?:[.,]\\d{1,2})?';
  var PRE = '(?:AU\\$|CA\\$|NZ\\$|NT\\$|MX\\$|US\\$|S\\$|R\\$|[$€£¥₹₩₺]|CHF|AED|DKK|NOK|SEK|PLN|INR|SAR|EGP|E£|TRY|ZAR|Rs\\.?)\\s?';
  var SUF = '\\s?(?:€|kr\\.?|zł|PLN|AED|CHF|Kč|DKK|NOK|SEK|SAR|TL|₺|\\$)';
  var RE_PRE = new RegExp('(' + PRE + ')(' + NUM + ')', 'g');
  var RE_SUF = new RegExp('(' + NUM + ')(' + SUF + ')', 'g');

  // first plausible price (>= 20 in local currency, skips "$0" shipping lines)
  function findPrice(text) {
    var best = null, m;
    RE_PRE.lastIndex = 0;
    while ((m = RE_PRE.exec(text || ''))) {
      var v = parseNumber(m[2]);
      if (v !== null && v >= 20) { best = { raw: m[0].trim(), value: v, idx: m.index }; break; }
    }
    RE_SUF.lastIndex = 0;
    while ((m = RE_SUF.exec(text || ''))) {
      var v2 = parseNumber(m[1]);
      if (v2 !== null && v2 >= 20 && (!best || m.index < best.idx)) { best = { raw: m[0].trim(), value: v2, idx: m.index }; break; }
    }
    return best ? { raw: best.raw, value: best.value } : null;
  }

  var DELIV = /(deliver|shipping|ships|arrives|dispatch|lieferung|versand|livraison|expédition|consegna|spedizione|entrega|envío|bezorg|levering|leverans|toimitus)/i;
  var DELIV2 = /(\d|days|business day|tage|jours|giorni|días|dagen|dage|dagar|päivä|free|kostenlos|gratuit|gratis|gratuita)/i;
  function findDelivery(text) {
    var lines = String(text || '').split(/[\n\r]+/);
    for (var i = 0; i < lines.length; i++) {
      var p = lines[i].trim();
      if (p.length > 2 && p.length < 160 && DELIV.test(p) && DELIV2.test(p)) return p.slice(0, 140);
    }
    var parts = String(text || '').split(/(?<=[.!])\s+(?=[A-ZÀ-Ý])/);
    for (var j = 0; j < parts.length; j++) {
      var q = parts[j].trim();
      if (q.length > 2 && q.length < 220 && DELIV.test(q) && DELIV2.test(q)) return q.slice(0, 140);
    }
    return '';
  }

  // Price from a short text that holds only the price (Amazon price element): symbol/currency code optional, any plausible number.
  function findPriceLoose(text) {
    var f = findPrice(text); if (f) return f;
    var m = new RegExp('(' + NUM + ')').exec(String(text || ''));
    if (!m) return null; var v = parseNumber(m[1]);
    return v !== null && v > 0 ? { raw: String(text).trim().slice(0, 30), value: v } : null;
  }

  // Amazon product page facts (read by the page script) -> status. Uses element ids, so it works in every language.
  function classifyAmazon(d) {
    d = d || {};
    if (d.atc && !d.atcDisabled) return 'IN_STOCK';
    if (d.preorder) return 'PREORDER';
    if (d.outOfStock || d.unavailable || d.seeAll) return 'OUT_OF_STOCK';
    if (d.atc && d.atcDisabled) return 'OUT_OF_STOCK';
    return 'UNKNOWN';
  }

  // How well two product titles match (0..1): share of words of the shorter one found in the other.
  function titleMatch(a, b) {
    var tk = function (x) { return String(x || '').toLowerCase().replace(/[^a-z0-9\u00c0-\uffff]+/g, ' ').split(' ').filter(function (w) { return w.length > 1; }); };
    var A = tk(a), B = tk(b); if (!A.length || !B.length) return 0;
    var small = A.length <= B.length ? A : B, big = A.length <= B.length ? B : A, hit = 0;
    small.forEach(function (w) { if (big.indexOf(w) !== -1) hit++; });
    return hit / small.length;
  }

  // which country store a URL belongs to ('US' when no prefix)
  function pathCountry(url) {
    try {
      var seg = new URL(url).pathname.split('/').filter(Boolean)[0] || '';
      if (/^[a-z]{2}$/i.test(seg) && seg.toLowerCase() !== 'ai') return seg.toUpperCase();
      if (/^[a-z]{2}-[a-z]{2}$/i.test(seg)) return seg.split('-')[1].toUpperCase();
    } catch (e) {}
    return 'US';
  }

  function buildUrl(cc, slug) {
    var prefix = '/' + cc.toLowerCase();
    return 'https://www.meta.com' + prefix + '/ai-glasses/' + slug + '/';
  }

  function round2(n) { return Math.round(n * 100) / 100; }

  // S: {fx:{CUR:usd}, includesVat, logisticsDefault, logistics:{CC:usd}, destDuty, destVat, margin}
  // row: {price (local), cur, cc, srcVat}
  function computeLanded(row, S) {
    var fx = S.fx && S.fx[row.cur];
    if (!row.price || !fx) return null;
    var usd = row.price * fx;
    // Source tax: mode 'included' = shown price already contains it, 'extra' = added at checkout. refund = you can recover / avoid it.
    var v = (Number(row.srcVat) || 0) / 100, mode = row.vatMode || 'included';
    var refund = row.refund == null ? !!S.includesVat : !!row.refund;
    var net = mode === 'extra' ? (refund ? usd : usd * (1 + v)) : (refund ? usd / (1 + v) : usd);
    var logOv = S.logistics && S.logistics[row.cc];
    var log = (logOv !== undefined && logOv !== '' && logOv !== null) ? Number(logOv) : Number(S.logisticsDefault || 0);
    var duty = (net + log) * (Number(S.destDuty) || 0) / 100;
    var vat = (net + log + duty) * (Number(S.destVat) || 0) / 100;
    var extra = Number(S.extra) || 0; // flat extra expenses per unit (clearing, handling...), not taxed
    var landed = net + log + duty + vat + extra;
    // B2C price = landed + margin + fixed. B2B price: own margin/fixed if set (blank = same as B2C). sameB2c = B2C price is made equal to the B2B price.
    var has = function (x) { return x !== undefined && x !== null && x !== ''; };
    var mC = Number(S.margin) || 0, fC = Number(S.fixed) || 0;
    var mB = has(S.marginB2b) ? Number(S.marginB2b) || 0 : mC, fB = has(S.fixedB2b) ? Number(S.fixedB2b) || 0 : fC;
    var sellB = landed * (1 + mB / 100) + fB;
    var sell = S.sameB2c ? sellB : landed * (1 + mC / 100) + fC;
    return { priceUsd: round2(usd), netUsd: round2(net), logistics: round2(log), duty: round2(duty), vat: round2(vat), extra: round2(extra), landed: round2(landed), sell: round2(sell), profit: round2(sell - landed),
      sellB2b: round2(sellB), profitB2b: round2(sellB - landed) };
  }

  function csvCell(v) {
    v = v === null || v === undefined ? '' : String(v);
    return /[",\n\r]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v;
  }
  function toCsv(headers, rows) {
    return [headers.map(csvCell).join(',')].concat(rows.map(function (r) { return r.map(csvCell).join(','); })).join('\r\n');
  }

  return { KW: KW, classify: classify, parseNumber: parseNumber, findPrice: findPrice, findDelivery: findDelivery,
    pathCountry: pathCountry, buildUrl: buildUrl, findPriceLoose: findPriceLoose, classifyAmazon: classifyAmazon, titleMatch: titleMatch, computeLanded: computeLanded, toCsv: toCsv };
});
